#include "ticketList.h"

/*
Name: Grant Murray
Course: CS 261
Date: 3/10/2023
Compile Instructions:
 * Cd into file containing your program and Makefile
 * Run the "make" command without quotations
 * Run "./ticketList" command without quotations
Program Description:
 * Loads tickets from text file and loads them into a doubly linked list
 * allows user to run various commands that can operate on list and save it back to file.
 * Also added "exit" command that allows you to leave the program without
 * saving the registry to file (usefull for testing purposes).
*/

int main() {
    // Initializes filename
    char filename[128] = "department_tickets.txt";

    // Opens file to be read by ticketInit
    FILE* ticketFile;
    ticketFile = fopen(filename, "r");

    // Loads up linked list with tickets using ticketInit
    ticketInit(ticketFile);

    // Closes file
    fclose(ticketFile);

    // Starts terminal input from user
    printf("\nWelcome to department ticket registry, choose from following commands:\n");
    printf(" - Add Ticket (add): Adds new ticket to registry\n");
    printf(" - Remove Ticket (remove): Removes ticket based on given title\n");
    printf(" - Sort Tickets (sort): Sorts tickets based on priority\n");
    printf(" - Print Tickets (print): Prints tickets based on order in registry\n");
    printf(" - Quit (quit): Quits program and saves registry to file\n");
    printf(" - Exit (exit): Exits program without saving registry to file\n\n");

    // Initializes user input
    char commandInput[32];

    // Starts user input stream
    while (strcmp(commandInput, "quit") != 0) {
        printf("Enter command: ");
        fgets(commandInput, 32, stdin);
        commandInput[strcspn(commandInput, "\n")] = 0;
        printf("\n");

        // Checks if user input corresponds to command
        if (strcmp(commandInput, "add") == 0) ticketAdd();
        else if (strcmp(commandInput, "remove") == 0) ticketRemove();
        else if (strcmp(commandInput, "sort") == 0 ) ticketSort();
        else if (strcmp(commandInput, "print") == 0) ticketPrint();
        else if (strcmp(commandInput, "quit") == 0) {
            fopen(filename, "w");
            quitOut(ticketFile);
            fclose(ticketFile);
            printf("Successfully quit program\n\n");
            return 0;
        }
        else if (strcmp(commandInput, "exit") == 0) {
            exitOut();
            printf("Successfully exited program\n\n");
            return 0;
        }
        
        // Improper command text
        else printf("Improper command\n\n");
        
        // Reprints available commands
		printf("\nCommands:\n");
		printf(" - add, remove, sort\n");
		printf(" - print, quit, exit\n\n");
    }

    return 0;
}
