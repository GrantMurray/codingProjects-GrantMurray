#include "ticketList.h"

Repair_Ticket* startTicket = NULL;
Repair_Ticket* endTicket = NULL;

// Initializes all tickets into linked list
int ticketInit(FILE* ticketFile) {
    // Checks if ticketFile exists
    if (ticketFile == NULL) return -1;

    // New temporary and previous ticket values
    Repair_Ticket* currTicket = NULL;
    Repair_Ticket* prevTicket = NULL;

    // Initialize current ticket
    currTicket = ticketRead(ticketFile);

    // Checks if file is empty
    if (currTicket == NULL) return 0;

    // Sets start pointers
    startTicket = currTicket;
    currTicket->prev = NULL;

    // Fills rest of list
    while (endTicket == NULL) {
        // Sets new temp ticket while saving last ticket in prev
        prevTicket = currTicket;
        
        currTicket = ticketRead(ticketFile);

        // Sets new pointers in array
        if (endTicket == NULL) {
            currTicket->prev = (struct Repair_Ticket *) prevTicket;
            prevTicket->next = (struct Repair_Ticket *) currTicket;
        }
        else {
            prevTicket->next = (struct Repair_Ticket *) endTicket;
            endTicket->prev = (struct Repair_Ticket *) prevTicket;
            endTicket->next = NULL;
        }
    }

    return 0;
}

// Reads ticket from file and allocates memory for new ticket struct
Repair_Ticket* ticketRead(FILE* ticketFile) {
    // New repair ticket
    char title[1024];
    char task[1024];
    int priority;

    // Fills ticket title, task, and priority
    fgets(title, 1024, ticketFile);
    if (strstr(title, "\n") == NULL) return NULL;
    title[strcspn(title, "\n")] = 0;
    title[strcspn(title, "\r")] = 0;
    fgets(task, 1024, ticketFile);
    task[strcspn(task, "\n")] = 0;
    task[strcspn(task, "\r")] = 0;
    priority = fgetc(ticketFile) - 48;

    // Allocates mem for new ticket
    Repair_Ticket* newTicket = ticketWrite(title, task, priority);
    
    // Skips blank space
    if (fgetc(ticketFile) != '\n') {
		fgetc(ticketFile);
		fgetc(ticketFile);
    }

    // Checks for EOF
    if (fgetc(ticketFile) == EOF) {
        if (startTicket == NULL) {
            startTicket = newTicket;
            startTicket->prev = NULL;
        }
        endTicket = newTicket;
        endTicket->next = NULL;
        return NULL;
    }

    return newTicket;
}

// Writes ticket with dynamic memory given title, task, and priority
Repair_Ticket* ticketWrite(char* title, char* task, int priority) {
    // Allocates memory for newTicket
    Repair_Ticket* newTicket = malloc(sizeof(Repair_Ticket));

    // If memory allocation failed then return NULL
    if (newTicket == NULL) {
        free(newTicket);
        return NULL;
    }

    // Allocates memory for variables
    newTicket->title = malloc(sizeof(char*) * (strlen(title)+1));
    newTicket->task = malloc(sizeof(char*) * (strlen(task)+1));

    // If memory allocation failed then return NULL
    if (newTicket->title == NULL || newTicket->task == NULL) {
        free(newTicket->title);
        free(newTicket->task);
        return NULL;
    }

    // Moves values into struct
    strcpy(newTicket->title, title);
    strcpy(newTicket->task, task);
    newTicket->priority = priority;

    return newTicket;
}

// Used to free memory given a ticket
int ticketFree(Repair_Ticket* currTicket) {
    // Frees all memory allocated for ticket struct
    currTicket->next = NULL;
    currTicket->prev = NULL;
    free(currTicket->title);
    free(currTicket->task);
    free(currTicket);
    
    return 0;
}

// Gets user input to add ticket to list
int ticketAdd() {
    // Initializes values for title, task, priority, and position
    char title[1024];
    char task[1024];
    char charPriority[32];
    char charPosition[32];
    int priority;
    int position;

    // Gets user input for title, task, and priority for new ticket
    printf("---- New Ticket ----\n");
    printf("Title: ");
    fgets(title, 1024, stdin);
    title[strcspn(title, "\n")] = 0;
    title[strcspn(title, "\r")] = 0;
    printf("Task: ");
    fgets(task, 1024, stdin);
    task[strcspn(task, "\n")] = 0;
    task[strcspn(task, "\r")] = 0;
    printf("Priority: ");
    fgets(charPriority, 32, stdin);
    priority = atoi(charPriority);
    if (priority > 4) priority = 4;
    else if (priority < 1) priority = 1;
    printf("Position: ");
    fgets(charPosition, 32, stdin);
    position = atoi(charPosition);
    printf("\n");

    // Constructs new ticket struct, prev ticket, and next ticket
    Repair_Ticket* prevTicket = NULL;
    Repair_Ticket* currTicket = ticketWrite(title, task, priority);
    Repair_Ticket* nextTicket = startTicket;

    // Start ticket check
    if (position <= 1 || startTicket == NULL) {
        if (startTicket == NULL) {
            startTicket = currTicket;
            startTicket->prev = NULL;
            endTicket = currTicket;
            endTicket->next = NULL;
            return 0;
        }
        startTicket = currTicket;
        startTicket->prev = NULL;
    }

    // Walks up to designated position
    while (position > 1) {
        // Incrementation
        prevTicket = (Repair_Ticket *) nextTicket;
        nextTicket = (Repair_Ticket *) nextTicket->next;
        position--;

        // Breaks at end
        if (nextTicket == NULL) break;
    }

    // Sets prev ticket connection
    if (currTicket != startTicket) prevTicket->next = (struct Repair_Ticket *) currTicket;
    currTicket->prev = (struct Repair_Ticket *) prevTicket;

    // Sets next ticket connection
    if (prevTicket != endTicket) nextTicket->prev = (struct Repair_Ticket *) currTicket;
    else endTicket = currTicket;
    currTicket->next = (struct Repair_Ticket *) nextTicket;

    return 0;
}

// Removes ticket from list given user input
int ticketRemove() {
    // Initializes value for title
    char title[1024];

    // Sets current ticket to start
    Repair_Ticket* prevTicket = NULL;
    Repair_Ticket* currTicket = startTicket;
    Repair_Ticket* nextTicket = NULL;

    // Checks if list is empty
    if (currTicket == NULL) {
        printf("No tickets to remove\n\n");
        return 0;
    }

    // Gets title from user
    printf("Title: ");
    fgets(title, 1024, stdin);
    title[strcspn(title, "\n")] = 0;
    title[strcspn(title, "\r")] = 0;
    printf("\n");

    // Loops through list
    while (currTicket != NULL) {
        // Checks if titles match
        if (strcmp(currTicket->title, title) == 0) {
            // Sets structs for prev and next
            prevTicket = (Repair_Ticket *) currTicket->prev;
            nextTicket = (Repair_Ticket *) currTicket->next;

            // Sets pointers to each other
            if (prevTicket != NULL && nextTicket != NULL) {
                prevTicket->next = (struct Repair_Ticket *) nextTicket;
                nextTicket->prev = (struct Repair_Ticket *) prevTicket;
            }

            // Sets new start ticket
            else if (prevTicket == NULL && nextTicket != NULL) {
                nextTicket->prev = NULL;
                startTicket = (Repair_Ticket *) nextTicket;
            }

            // Sets new end ticket
            else if (prevTicket != NULL && nextTicket == NULL) {
                prevTicket->next = NULL;
                endTicket = (Repair_Ticket *) prevTicket;
            }

            // Clears list
            else {
                startTicket = NULL;
                endTicket = NULL;
            }

            // Frees memory for current ticket
            ticketFree(currTicket);

            return 0;
        }

        // Incrementation
        currTicket = (Repair_Ticket *) currTicket->next;
    }

    // Prints that there was no ticket
    printf("No ticket with title: %s\n\n", title);

    return 0;
}

// Sorts all tickets based on priority
int ticketSort() {
    // Declares new structs and prints state of sorting
    Repair_Ticket* currTicket = (Repair_Ticket *) startTicket;
    if (currTicket == NULL) {
    	printf("No tickets to sort\n\n");
    	return 0;
    }
    Repair_Ticket* nextTicket = (Repair_Ticket *) startTicket->next;
    if (nextTicket == NULL) {
    	printf("Can't sort one ticket\n\n");
    	return 0;
    }
    printf("Tickets successfully sorted\n\n");

    // Declares test variable swapSort
    int swapSort = 1;

    while (swapSort == 1) {
        // Resets swapSort
        swapSort = 0;

        // Checks if at end of list
        while (currTicket != NULL && nextTicket != NULL) {
            // Checks if out of order
            if (currTicket->priority > nextTicket->priority) {
                ticketSwap(currTicket, nextTicket);
                swapSort = 1;
            }

            // Increments tickets
            currTicket = (Repair_Ticket *) currTicket->next;
            nextTicket = (Repair_Ticket *) nextTicket->next;
        }

        // Resets ticket loop
        currTicket = (Repair_Ticket *) startTicket;
        nextTicket = (Repair_Ticket *) currTicket->next;
    }

    return 0;
}

// Small function used to swap two tickets passed into function
int ticketSwap(Repair_Ticket* currTicket, Repair_Ticket* nextTicket) {
    // Curr values
    char* currTitle = currTicket->title;
    char* currTask = currTicket->task;
    int currPriority = currTicket->priority;

    // Next values
    char* nextTitle = nextTicket->title;
    char* nextTask = nextTicket->task;
    int nextPriority = nextTicket->priority;

    // Swap curr struct
    currTicket->title = nextTitle;
    currTicket->task = nextTask;
    currTicket->priority = nextPriority;

    // Swap next struct
    nextTicket->title = currTitle;
    nextTicket->task = currTask;
    nextTicket->priority = currPriority;

    return 0;
}

// Prints out all tickets based on order in department tickets
int ticketPrint() {
    // Sets up ticket cursor
    Repair_Ticket* currTicket = startTicket;

    if (startTicket == NULL) printf("No tickets to print\n\n");

    // While loop to print out struct array
    while (currTicket != NULL) {
        printf("%s\n", currTicket->title);
        printf("%s\n", currTicket->task);
        printf("%i\n\n", currTicket->priority);
        currTicket = (Repair_Ticket *) currTicket->next;
    }

    return 0;
}

// Saves all tickets to department tickets file and quits safely
int quitOut(FILE* ticketFile) {
    // Sets up ticket cursor
    Repair_Ticket* prevTicket = NULL;
    Repair_Ticket* currTicket = startTicket;

    // While loop to print out struct array and free it
    while (currTicket != NULL) {
        fprintf(ticketFile, "%s\n", currTicket->title);
        fprintf(ticketFile, "%s\n", currTicket->task);
        fprintf(ticketFile, "%i", currTicket->priority);
        prevTicket = (Repair_Ticket *) currTicket;
        currTicket = (Repair_Ticket *) currTicket->next;
        free(prevTicket);
        if (currTicket != NULL) fprintf(ticketFile, "\n\n");
    }

    return 0;
}

// Exit command for testing (doesn't save to file)
int exitOut() {
    // Sets up ticket cursor
    Repair_Ticket* prevTicket = NULL;
    Repair_Ticket* currTicket = startTicket;

    // While loop to free variables
    while (currTicket != NULL) {
        prevTicket = (Repair_Ticket *) currTicket;
        currTicket = (Repair_Ticket *) currTicket->next;
        free(prevTicket);
    }

    return 0;
}