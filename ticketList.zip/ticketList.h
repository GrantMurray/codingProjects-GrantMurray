#ifndef PROG3_TICKETLIST_H
#define PROG3_TICKETLIST_H
#endif //PROG3_TICKETLIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct REPAIRTICKET {
    char *title;
    char *task;
    int priority;
    struct Repair_Ticket* next;
    struct Repair_Ticket* prev;
} Repair_Ticket;

int ticketInit(FILE* ticketFile);
Repair_Ticket* ticketRead(FILE* ticketFile);
Repair_Ticket* ticketWrite(char* title, char* task, int priority);
int ticketAdd();
int ticketRemove();
int ticketSort();
int ticketSwap(Repair_Ticket* currTicket, Repair_Ticket* nextTicket);
int ticketPrint();
int quitOut(FILE* ticketFile);
int exitOut();
