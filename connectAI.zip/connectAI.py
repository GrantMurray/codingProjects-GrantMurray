import random

class Connect4:
    def __init__(self, width, height, window=None):
        self.width = width
        self.height = height
        self.playturn = 'x'
        self.data = []
        
        for row in range(self.height):
            boardRow = []
            for col in range(self.width):
                boardRow += [' ']
            self.data += [boardRow]
        
    def __repr__(self):
        s = ''
        for row in range(self.height):
            s += '|'
            for col in range(self.width):
                s += self.data[row][col] + '|'
            s += '\n'
        for i in range(self.width * 2 + 1):
            s +=  '-'
        s += '\n'
        for i in range(self.width):
            s += ' ' + str(i % 10)
        s += '\n'
        return s
        

    def clear(self):
        for row in range(self.height):
            for col in range(self.width):
                self.data[row][col] = ' '

    def isFull(self):
        for col in range(self.width):
            if self.allowsMove(col):
                return False
        return True

    def winsFor(self, ox):
        for row in range(self.height):
            for col in range(self.width - 3):
                if self.data[row][col] == ox and \
                self.data[row][col+1] == ox and \
                self.data[row][col+2] == ox and \
                self.data[row][col+3] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width):
                if self.data[row][col] == ox and \
                self.data[row + 1][col] == ox and \
                self.data[row + 2][col] == ox and \
                self.data[row + 3][col] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row][col] == ox and \
                self.data[row + 1][col + 1] == ox and \
                self.data[row + 2][col + 2] == ox and \
                self.data[row + 3][col + 3] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row][col + 3] == ox and \
                self.data[row + 1][col + 2] == ox and \
                self.data[row + 2][col + 1] == ox and \
                self.data[row + 3][col] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row + 3][col] == ox and \
                self.data[row + 2][col + 1] == ox and \
                self.data[row + 1][col + 2] == ox and \
                self.data[row][col + 3] == ox:
                    return True

        return False


    def addMove(self, col, ox):
        for i in range(self.height + 1):
            if self.allowsMove(col):
                i = -(i + 1)
                if self.data[i][col] == ' ':
                    self.data[i][col] = ox
                    break

    def delMove(self, col):
        for i in range(self.height):
            if self.data[i][col] != ' ':
                self.data[i][col] = ' '
                break

    def allowsMove(self, col):
        if col < self.width and col >= 0:
            for i in range(self.height):
                if self.data[i][col] == ' ':
                    return True
        return False

    def flipTurn(self, ox):
        if ox == 'o':
            return 'x'
        elif ox == 'x':
            return  'o'

    def playGameWith(self, aiPlayer):
        self.clear()
        while True:
            print(self)
            print('Player turn: ' + self.playturn)
            move = int(input('Column: '))
            if self.allowsMove(move):
                self.addMove(move, self.playturn)
            else:
                print('Invalid move!')

            if self.winsFor(self.playturn):
                print(self)
                print(self.playturn + ' won!')
                break
            elif self.isFull():
                print('Game over!')
                break

            if self.allowsMove(move):
                self.addMove(aiPlayer.nextMove(self), self.flipTurn(self.playturn))

                if self.winsFor(self.flipTurn(self.playturn)):
                    print(self)
                    print(self.flipTurn(self.playturn) + ' won!')
                    break
                elif self.isFull():
                    print('Game over!')
                    break
                

    def hostGame(self): 
        self.clear()
        while True:
            print(self)
            if self.winsFor(self.flipTurn(self.playturn)):
                print(self.flipTurn(self.playturn) + ' won!')
                break
            elif self.isFull():
                print('Game over!')
                break

            print('Player turn: ' + self.playturn)
            move = int(input('Column: '))
            if self.allowsMove(move):
                self.addMove(move, self.playturn)
                self.playturn = self.flipTurn(self.playturn)
            else:
                print('Invalid move!')
    
class Player:
    def __init__(self, ox, tbt, ply):
        self.checker = ox
        self.tieBreakType = tbt
        self.ply = ply


    def scoresFor(self, board, ox, ply):
        L1 = [0 for i in range(board.width)]
        if ply == 0:
            for col in range(board.width):
                if board.allowsMove(col):
                    board.addMove(col, ox)
                    if board.winsFor(ox):
                        L1[col] = 100
                    elif board.winsFor(board.flipTurn(ox)):
                        L1[col] = 0
                    else:
                        L1[col] = 50
                    board.delMove(col)
        else:
            for col in range(board.width):
                if board.allowsMove(col):
                    board.addMove(col, ox)
                    if board.winsFor(ox):
                        if board.winsFor(board.flipTurn(ox)):
                            L1[col] = 0
                        else:
                            L1[col] = 100
                    elif board.winsFor(board.flipTurn(ox)):
                        L1[col] = 0
                    else:
                        L1[col] = 50
                    if ply > 1:
                        L2 = self.scoresFor(board, board.flipTurn(ox), ply - 1)
                        if board.winsFor(ox):
                            L1[col] = 100 - max(L2)/2
                        else:
                            L1[col] = 100 - max(L2)/2
                    board.delMove(col)

        return L1
                

    def tieBreak(self, L):
        if self.tieBreakType == 'Left':
            m = L.index(max(L))
        elif self.tieBreakType == 'Right':
            x = 0
            for j,i in enumerate(L):
                if i >= x:
                    x = i
                    m = j
        elif self.tieBreakType == 'Random':
            x = 0
            y = random.randint(0, len(L))
            for j,i in enumerate(L):
                if i >= x and j < y:
                    x = i 
                    m = j
        return m

    def nextMove(self, board):
        L = self.scoresFor(board, self.checker, self.ply)
        print(L)
        L = self.tieBreak(L)
        return L


def main():
    D = Connect4(7, 7)
    P = Player('o', 'Right', 2)
    D.playGameWith(P)

if __name__ == '__main__':
    main()