from turtle import *
import random


def drawPetal1(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color((250, 100 + random.randint(0, 80), 10))
	begin_fill()
	for k in range(2):
		for i in range(80):
			forward(8 - i/10)
			right(1)
		right(100)
	end_fill()

def drawPetal2(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color((0, 0 + random.randint(0, 100), 250))
	begin_fill()
	for i in range(100):
		forward(4 - i/60)
		right(1)
	right(180)
	for i in range(100):
		forward(4 - i/80)
		left(1)
	end_fill()

def drawPetals(r=0, x=0, y=0):
	for i in [20 + r, 50 + r]:
		drawPetal1(i, x - i, y - i/2)

	color((250, 100 + random.randint(0, 80), 200))
	left(180)
	begin_fill()
	for i in range(40):
		forward(6 - i/10)
		left(1)
	left(50)
	forward(20)
	left(120)
	for i in range(60):
		forward(6 - i/10)
		right(1)
	end_fill()

def drawStem1(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color((0, 80 + random.randint(0, 100), 100))
	begin_fill()
	for i in range(135):
		forward(5 - i/250)
		left(1)
	right(240)
	for i in range(80):
		forward(12 - i/50)
		right(1)
	end_fill()

def drawStem2(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color('lightgreen')
	begin_fill()
	for i in range(100):
		forward(10 - i/10)
		left(1)
	right(180)
	for i in range(60):
		forward(10 - i/10)
		right(2)
	end_fill()

def drawStem3(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color('lightgreen')
	begin_fill()
	for i in range(60):
		forward(8)
		left(0.5)
	left(50)
	forward(70)
	left(130)
	for i in range(60):
		forward(8 )
		right(0.5)
	end_fill()

def drawStem4(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color((150 + random.randint(0, 100), 50, 100))
	begin_fill()
	for i in range(60):
		forward(6 - i/10)
		left(1)
	left(50)
	forward(100)
	left(110)
	for i in range(80):
		forward(8 - i/10)
		right(1)
	end_fill()

def drawFlower(x=0,y=0):
	drawPetals(0, 0+x, y)
	drawPetals(50, -100+x, y)
	drawPetal2(100, -50+x, -200+y)
	drawPetals(-20, 50+x, -50+y)
	drawPetal2(120, -100+x, -200+y)
	drawStem1(120, 180+x, -280+y)
	drawStem2(150, 150+x, -300+y)
	drawStem3(100, 500+x, -820+y)
	drawStem4(120, 320+x, -410+y)

def drawLeaf(r=0, x=0, y=0):
	penup()
	setx(x)
	sety(y)
	pendown()
	setheading(r)
	color('darkgreen')
	begin_fill()
	for k in range(2):
		for i in range(80):
			forward(10)
			right(1)
		right(80)
	end_fill()


def setupTurtle():
	tracer(00)
	hideturtle()
	colormode(255)
	screensize(1000, 1000, 'white')

def main():
	setupTurtle()
	drawFlower(-200,0)
	drawFlower(200,200)
	ts = getscreen()
	ts.getcanvas().postscript(file="flower.jpeg")
	done()
	

if __name__ == '__main__':
	main()