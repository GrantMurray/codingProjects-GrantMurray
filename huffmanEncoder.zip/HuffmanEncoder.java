import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

public class HuffmanEncoder {
    
    public Node root = null;

    public String uniString = "";
    public int leafCount;

    /**
     * You can use this node implementation for building your Huffman tree.
     * Feel free to change it, but be sure to update at least compareTo
     * so it will work correctly with the MinHeap
     */
    private class Node implements Comparable<Node>{
        public Node left, right;
        public Character c;
        public int count;

        public Node(Character c, int count) {
            this.c = c;
            this.count = count;
            left = right = null;
        }

        @Override
        public int compareTo(Node o) {
            return count - o.count;
        }

        @Override
        public String toString() {
            if(c == null) { return "null-" + count; }
            return c.toString() + "-" + count;
        }
    }


    public HuffmanEncoder() {
    }

    /**
     * Huffman Part 1: Implement this
     *
     * Generates:
     *      1) Huffman tree
     *      2) Encoded version of same
     *      3) Character bit strings
     *      4) Encoded version of string
     *
     * @param s -- String to be Huffman encoded
     */
    public void encode(String s) {
        uniString = s;
        
        MinHeapPriorityQueue<Node> heap = new MinHeapPriorityQueue<>();

        int[] counts = new int[256];
        for(int i = 0; i < s.length(); i++) {
            counts[s.charAt(i)]++;
        }

        for (int i = 0 ; i < counts.length ; i++) {
            if (counts[i] != 0) {
                char intChar = (char) i;
                heap.insert(new Node(intChar, counts[i]));
                leafCount++;
            }
        }
        while (heap.size() > 1) {
            Node child1 = heap.delNext();
            Node child2 = heap.delNext();
            root = new Node(null, child1.count + child2.count);
            root.right = child2;
            root.left = child1;
            heap.insert(root);
        }
    }


    /**
     * Huffman Part 2: Implement this
     *
     * Your string encoding should use the actual letter rather than an
     * ASCII code. So if you are outputting a capital letter A, write "A",
     * not 65.
     *
     * @return String encoding of Huffman tree, as per slides
     */
    public String getEncodedTree() {
        ArrayList<Node> seen = new ArrayList<>();
        String output = "";
        Node sweepNode = root;
        Stack<Node> stack = new Stack<>();

        if (root != null) {
            stack.push(root);
            output += "0";
        }

        while (!stack.isEmpty()) {
            while (sweepNode.left != null & !seen.contains(sweepNode.left)) {

                stack.push(sweepNode);
                sweepNode = sweepNode.left;
                if (!seen.contains(sweepNode)) {
                    if (sweepNode.c != null) {
                        output += "1" + sweepNode.c;
                    } else {
                        output += "0";
                    }
                    seen.add(sweepNode);
                }
            }

            sweepNode = stack.pop();

            if (sweepNode.right != null & !seen.contains(sweepNode.right)) {
                stack.push(sweepNode);
                sweepNode = sweepNode.right;
                if (!seen.contains(sweepNode)) {
                    if (sweepNode.c != null) {
                        output += "1" + sweepNode.c;
                    } else {
                        output += "0";
                    }
                    seen.add(sweepNode);
                }
            }
        }
       return output;
    }

    /**
     * Huffman Part 3: Implement this
     *
     * Returns an array of encoded bit strings.
     * Array should have 256 entries (one for each character value 0-255).
     * Entries that correspond to a character in the input should contain
     * the bitstring for that character.
     * Entries whose characters are not in the input should be null.
     *
     * Hint: the trick used for tracking counts in the slides would help here
     *
     * @return array of encoded bit strings
     */
    public String[] getBitStrings() {
        int leaves = leafCount;
        String bitstring = "";
        ArrayList<Node> seen = new ArrayList<>();
        String[] stringList = new String[256];
        Node sweepNode = root;

        while (leaves > 0) {
            if (sweepNode.left != null & !seen.contains(sweepNode.left)) {
                sweepNode = sweepNode.left;
                bitstring += "0";
                if (sweepNode.c != null) {
                    seen.add(sweepNode);
                    int charInt = (int) sweepNode.c;
                    stringList[charInt] = bitstring;
                    leaves--;
                }
            }
            else if (sweepNode.right != null & !seen.contains(sweepNode.right)) {
                sweepNode = sweepNode.right;
                bitstring += "1";
                if (sweepNode.c != null) {
                    seen.add(sweepNode);
                    int charInt = (int) sweepNode.c;
                    stringList[charInt] = bitstring;
                    leaves--;
                }
            }
            else {
                seen.add(sweepNode);
                sweepNode = root;
                bitstring = "";

            }
        }

        return stringList;
    }

    /**
     * Huffman Part 4: Implement this
     *
     * Returns a string corresponding to the Huffman encoding of the
     * string provided to encode(). String should contain only '0's
     * and '1's (i.e. be binary). Other characters will be considered
     * incorrect.
     *
     * @return 'bit' encoding of overall string
     */
    public String getEncodedText() {
        String output = "";
        int stringInt = 0;
        String[] stringArray = getBitStrings();
        char[] stringChars = uniString.toCharArray();

        for (char c : stringChars) {
            stringInt = (int) c;
            String bitstring = (String) stringArray[stringInt];
            output += bitstring;
        }
        return output;
    }


    public static void main(String args[]) {
        HuffmanEncoder he = new HuffmanEncoder();

        he.encode("ABRACADABRA!");
        System.out.println(he.getEncodedTree());
        System.out.println(he.getEncodedText());
        System.out.println(he.getEncodedText().length() + " <-- should be 28");
    }

}

class MinHeapPriorityQueue<I extends Comparable<I>> implements PriorityQueue<I> {
    // Java doesn't like creating arrays of generic types
    // I'm providing code that will manage this array for you
    private I[] heap;
    private int N;      // number of elements in the heap

    // Java would normally warn us about the cast below.
    // this directive keeps that from happening
    @SuppressWarnings("unchecked")
    public MinHeapPriorityQueue() {
        N = 0;
        heap = (I[]) new Comparable[1];
    }

    /**
     * Priority Queue Part 1: Implement this
     *
     * Insert an item into the priority queue, performing
     * sift/swim operations as appropriate. You *must* maintain
     * a heap array. No fair just searching for the smallest value later
     *
     * Make a call to resize() when you need to resize the array
     *
     * @param item -- Item to insert into the queue
     */
    @Override public void insert(I item) {
        if (heap.length == N) {
            resize();
        }
        int pos = N;
        heap[pos] = item; N++;
        if (N > 1) {
            while (heap[pos].compareTo(heap[(pos-1)/2]) < 0) {
                I parent = heap[(pos-1)/2];
                heap[(pos-1)/2] = heap[pos];
                heap[pos] = parent;
                pos = (pos-1)/2;
            }
        }
    }

    /**
     * Priority Queue Part 2: Implement this
     *
     * Extract the next item from queue, perform appropriate sift/swim
     * operations, and return the item. You *must* maintain a heap array.
     * No fair just searching for the smallest value.
     *
     * @return Item with highest priority (i.e. one with lowest value)
     */
    @Override public I delNext() {
        int pos = 0;
        I min = heap[0];
        heap[0] = heap[N-1];
        heap[N-1] = null; N--;
        int posL = 1;
        int posR = 2;

        if (N == 2) {
            if (heap[0].compareTo(heap[1]) > 0) {
                I parent = heap[0];
                heap[0] = heap[1];
                heap[1] = parent;
            }
        }

        while(posR < N) {
            if (heap[pos].compareTo(heap[posL]) < 0 & heap[pos].compareTo(heap[posR]) < 0) {
                break;
            }
            if (heap[posL].compareTo(heap[posR]) < 0) {
                I parent = heap[pos];
                heap[pos] = heap[posL];
                heap[posL] = parent;
                pos = 2*pos+1;
            }
            else {
                I parent = heap[pos];
                heap[pos] = heap[posR];
                heap[posR] = parent;
                pos = 2*pos+2;
            }
            posL = 2*pos+1;
            posR = 2*pos+2;
        }
        return min;
    }

    /**
     * I assume you use N to track number of items in the heap.
     * If that's not the case, update this method.
     *
     * @return number of items in the heap
     */
    @Override public int size() {
        return N;
    }

    /**
     * Doubles the size of the heap array. Takes care of allocating
     * memory and moving everything, so you don't have to.
     * Call this from insert when you need more array space.
     */
    private void resize() {
        @SuppressWarnings("unchecked")
        I[] newHeap = (I[]) new Comparable[heap.length * 2];
        for(int i = 0; i < N; i++) {
            newHeap[i] = heap[i];
        }
        heap = newHeap;
    }

    /**
     * Returns a stringified version of the array. You shouldn't
     * need to mess with this if you use the heap array. If you do
     * something else, make sure this method still works properly
     * based on whatever your heap storage is, and the format matches exactly.
     *
     * @return a comma-separated list of array values, wrapped in brackets
     */
    @Override public String toString() {
        if(N == 0) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i = 0; i < N-1; i++) {
            sb.append(heap[i] + ",");
        }
        sb.append(heap[N-1] + "]");
        return sb.toString();
    }

    public static void main(String args[]) {
        MinHeapPriorityQueue<Integer> pq = new MinHeapPriorityQueue<>();

        pq.insert(5);
        pq.insert(11);
        pq.insert(8);
        pq.insert(4);
        pq.insert(3);
        pq.insert(15);
        System.out.println(pq + " <-- should be [3,4,8,11,5,15]");

        for(int i = 0; i < 6; i++) {
            System.out.println(pq.delNext());
        }
    }
}
