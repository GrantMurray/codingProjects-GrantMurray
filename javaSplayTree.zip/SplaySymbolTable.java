import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Stack;
import java.util.Vector;

public class SplaySymbolTable<K extends Comparable<K>, V> implements SymbolTable<K, V> {

    private class Node {
        K key;
        V val;
        Node left, right;
        Node parent;

        Node(K k, V v) {
            key = k;
            val = v;
            parent = null;
        }

        Node(K k, V v, Node p) {
            key = k;
            val = v;
            parent = p;
        }
    }

    private Node root;

    public SplaySymbolTable() {
        root = null;
    }

    private Node rotateRight(Node p) {
        Node c = p.left;
        if (p == root) root = c;
        if (c.right != null) c.right.parent = p;
        if (p.parent != null) {
            if (p.parent.left == p) p.parent.left = c;
            else p.parent.right = c;
        }
        c.parent = p.parent;
        p.parent = c;
        p.left = c.right;
        c.right = p;
        return c;
    }

    private Node rotateLeft(Node p) {
        Node c = p.right;
        if (p == root) root = c;
        if (c.left != null) c.left.parent = p;
        if (p.parent != null) {
            if (p.parent.right == p) p.parent.right = c;
            else p.parent.left = c;
        }
        c.parent = p.parent;
        p.parent = c;
        p.right = c.left;
        c.left = p;
        return c;
    }

    private void splay(Stack<Node> path) {
        Node x = path.pop();
        while (path.size() >= 2) {
            Node p = path.pop();
            Node g = path.pop();
            if (g.left == p) {
                if (p.left == x) { // zig-zig
                    x = rotateRight(rotateRight(g));
                } else { // zig-zag
                    g.left = rotateLeft(p);
                    x = rotateRight(g);
                }
            } else {
                if (p.left == x) { // zag-zig
                    g.right = rotateRight(p);
                    x = rotateLeft(g);
                } else { // zag-zag
                    x = rotateLeft(rotateLeft(g));
                }
            }
            if (path.isEmpty()) // re-attach splayed subtree
                root = x;
            else if (path.peek().right == g)
                // peak returns the top stack object without removing it
                path.peek().right = x;
            else
                path.peek().left = x;
        }
        if (!path.isEmpty())
            root = (root.left == x) ? rotateRight(root) : rotateLeft(root);
    }

    /**
     * Splay target to root using parent references -- Part 1: Implement this
     * <p>
     * This method serves the same purpose as the above (implemented) splay,
     * but relies on nodes having parent references, rather than a separately
     * maintained stack representing the traversal path
     *
     * @param x node to splay to root
     */
    private void splay(Node x) {
        if (x == root) return;

        while (x != root) {
            if (x.parent == root) {
                if (x.parent.left == x) rotateRight(x.parent);
                else rotateLeft(x.parent);
                break;
            }

            else {
                if (x.parent.parent.left == x.parent) {
                    if (x.parent.left == x) {
                        rotateRight(x.parent.parent);
                        rotateRight(x.parent);
                    }
                    else {
                        rotateLeft(x.parent);
                        rotateRight(x.parent);
                    }
                }
                else {
                    if (x.parent.right == x) {
                        rotateLeft(x.parent.parent);
                        rotateLeft(x.parent);
                    }
                    else {
                        rotateRight(x.parent);
                        rotateLeft(x.parent);
                    }
                }
            }
        }
    }

    @Override
    public void insert(K key, V val) {
        if (root == null) {
            root = new Node(key, val);
            return;
        }
        Node sweepNode = root;
        Node insertNode = new Node(key, val);
        while (true) {
            int cmp = key.compareTo(sweepNode.key);
            if (cmp < 0) {
                if (sweepNode.left == null) {
                    sweepNode.left = insertNode;
                    insertNode.parent = sweepNode;
                    break;
                }
                sweepNode = sweepNode.left;
            } else {
                if (sweepNode.right == null) {
                    sweepNode.right = insertNode;
                    insertNode.parent = sweepNode;
                    break;
                }
                sweepNode = sweepNode.right;
            }
        }
        splay(insertNode);
    }

    @Override
    public V search(K key) {
        if (root == null)
            return null;
        Node sweepNode = root;
        V val = null;
        while (true) {
            int cmp = key.compareTo(sweepNode.key);
            if (cmp == 0) {
                val = sweepNode.val;
                break;
            }
            if (cmp < 0) {
                if (sweepNode.left == null) break;
                sweepNode = sweepNode.left;
            } else {
                if (sweepNode.right == null) break;
                sweepNode = sweepNode.right;
            }
        }
        splay(sweepNode);
        return val;
    }

    /*
     * This is here so you can see it. You don't need to do anything with it,
     * and can safely ignore it if you prefer.
     */
    public V remove(K key) {
        if (root == null)
            return null;

        Stack<Node> path = new Stack<Node>();
        Node x = root;
        while (x != null) {
            path.push(x);
            int cmp = key.compareTo(x.key);
            if (cmp < 0)
                x = x.left;
            else if (cmp > 0)
                x = x.right;
            else
                break; // key found
        }

        if (x == null) {
            splay(path);
            return null;
        }

        V val = x.val;

        if (x.left == null) {
            path.pop();
            if (path.isEmpty()) {
                root = x.right;
            } else {
                Node p = path.peek();
                if (p.left == x)
                    p.left = x.right;
                else
                    p.right = x.right;
            }
        } else if (x.right == null) {
            path.pop();
            if (path.isEmpty()) {
                root = x.left;
            } else {
                Node p = path.peek();
                if (p.left == x)
                    p.left = x.left;
                else
                    p.right = x.left;
            }
        } else {
            Node m = x.right;
            while (m.left != null) {
                path.push(m);
                m = m.left;
            }
            x.key = m.key;
            x.val = m.val;
            if (x.right == m)
                x.right = m.right;
            else {
                Node p = path.peek();
                p.left = m.right;
            }
        }

        splay(path);
        return val;
    }

    private void serializeAux(Node tree, Vector<String> vec) {
        if (tree == null)
            vec.addElement(null);
        else {
            vec.addElement(tree.key.toString() + ":black");
            serializeAux(tree.left, vec);
            serializeAux(tree.right, vec);
        }
    }

    public Vector<String> serialize() {
        Vector<String> vec = new Vector<String>();
        serializeAux(root, vec);
        return vec;
    }

    void printTree(String fname) {
        Vector<String> st = serialize();
        TreePrinter treePrinter = new TreePrinter(st);
        treePrinter.fontSize = 14;
        treePrinter.nodeRadius = 14;
        try {
            FileOutputStream out = new FileOutputStream(fname);
            PrintStream ps = new PrintStream(out);
            treePrinter.printSVG(ps);
        } catch (FileNotFoundException e) {
        }
    }

    public static void main(String[] args) {
        SplaySymbolTable<Integer, Integer> table = new SplaySymbolTable<>();
        int[] keys = {1, 2, 3, 4, 9, 8, 7, 6};
        for (int i = 0; i < keys.length; i++) {
            table.insert(keys[i], keys[i]);

        }
        table.printTree("splay-tree-1.svg");
        table.search(3);
        table.search(9);
        table.search(7);
        table.printTree("splay-tree-2.svg");


        /*
            The following code provides some additional testing and uses
            the remove method, which, again, you don't need to mess with.
        !! Close the above comment to active the remaining code

        SplaySymbolTable<Integer, Integer> symtab = new SplaySymbolTable<>();
        for (int i = 0; i < 10; i++)
            symtab.insert(i, i);
        symtab.printTree("splay-insert-10.svg");

        Integer I = symtab.search(0);
        System.out.println("searched/found " + I);
        symtab.printTree("splay-search-0.svg");

        I = symtab.remove(7);
        System.out.println("removed/found " + I);
        symtab.printTree("splay-remove-7.svg");

        I = symtab.remove(1);
        System.out.println("removed/found " + I);
        symtab.printTree("splay-remove-1.svg");

        //*/
    }

}
