import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Stack;
import java.util.Vector;

public class SplaySymbolTable<K extends Comparable<K>, V> implements SymbolTable<K, V> {

    private class Node {
        K key;
        V val;
        Node left, right;
        Node parent;

        Node(K k, V v) {
            key = k;
            val = v;
            parent = null;
        }

        Node(K k, V v, Node p) {
            key = k;
            val = v;
            parent = p;
        }
    }

    private Node root;

    public SplaySymbolTable() {
        root = null;
    }

    private Node rotateRight(Node n) {
        Node p = n.parent;
        Node c = n.left;
        Node r = c.right;
        if (p != null) {
            if (p.left == n) p.left = c;
            else p.right = c;
        }
        c.parent = p;
        n.parent = c;
        c.right = n;
        n.left = r;
        if (r!= null) r.parent = n;
        return c;
    }

    private Node rotateLeft(Node n) {
        Node p = n.parent;
        Node c = n.right;
        Node l = c.left;
        if (p != null) {
            if (p.left == n) p.left = c;
            else p.right = c;
        }
        c.parent = p;
        n.parent = c;
        c.left = n;
        n.right = l;
        if (l != null) l.parent = n;
        return c;
    }

    /**
     * Splay target to root using parent references -- Part 1: Implement this
     * <p>
     * This method serves the same purpose as the above (implemented) splay,
     * but relies on nodes having parent references, rather than a separately
     * maintained stack representing the traversal path
     *
     * @param x node to splay to root
     */
    private void splay(Node x) {


        // Main splay loop
        while (x != root) {

            // Node's parent is root
            if (x.parent.parent == null) {
                // Left of parent
                if (x.parent.left == x) {
                    rotateRight(x.parent);
                }
                // Right of parent
                else {
                    rotateLeft(x.parent);
                }
                root = x;
            }

            // Depth of node is more than 2
            else {
                // Left cases
                if (x.parent.parent.left == x.parent) {
                    // Left left
                    if (x.parent.left == x) {
                        rotateRight(x.parent.parent);
                        rotateRight(x.parent);
                    }
                    // Left right
                    else {
                        rotateLeft(x.parent);
                        rotateRight(x.parent);
                    }
                }
                // Right cases
                else {
                    // Right right
                    if (x.parent.right == x) {
                        rotateLeft(x.parent.parent);
                        rotateLeft(x.parent);
                    }
                    // Right left
                    else {
                        rotateRight(x.parent);
                        rotateLeft(x.parent);
                    }
                }
                // Check if node is now root
                if (x.parent == null) {
                    root = x;
                }
            }
        }
    }

    @Override
    public void insert(K key, V val) {

        // Insert root
        Node insertNode = new Node(key, val);
        if (root == null) {
            root = insertNode;
            return;
        }
        Node sweepNode = root;
        while (true) {
            int cmp = key.compareTo(sweepNode.key);
            if (cmp < 0) {
                if (sweepNode.left == null) {
                    sweepNode.left = insertNode;
                    insertNode.parent = sweepNode;
                    break;
                }
                sweepNode = sweepNode.left;
            }
            else {
                if (sweepNode.right == null) {
                    sweepNode.right = insertNode;
                    insertNode.parent = sweepNode;
                    break;
                }
                sweepNode = sweepNode.right;
            }
        }
        splay(insertNode);
    }

    @Override
    public V search(K key) {
        if (root == null)
            return null;
        Node x = root;
        V val = null;
        while (true) {
            int cmp = key.compareTo(x.key);
            if (cmp == 0) {
                val = x.val;
                break;
            }
            if (cmp < 0) {
                if (x.left == null) break;
                x = x.left;
            } else {
                if (x.right == null) break;
                x = x.right;
            }
        }
        splay(x);
        return val;
    }

    /*
     * This is here so you can see it. You don't need to do anything with it,
     * and can safely ignore it if you prefer.
     */
    public V remove(K key) {
        if (root == null)
            return null;

        Stack<Node> path = new Stack<Node>();
        Node x = root;
        while (x != null) {
            int cmp = key.compareTo(x.key);
            if (cmp < 0)
                x = x.left;
            else if (cmp > 0)
                x = x.right;
            else
                break; // key found
        }

        if (x == null) {
            splay(x);
            return null;
        }

        V val = x.val;

        if (x.left == null) {
            path.pop();
            if (path.isEmpty()) {
                root = x.right;
            } else {
                Node p = path.peek();
                if (p.left == x)
                    p.left = x.right;
                else
                    p.right = x.right;
            }
        } else if (x.right == null) {
            path.pop();
            if (path.isEmpty()) {
                root = x.left;
            } else {
                Node p = path.peek();
                if (p.left == x)
                    p.left = x.left;
                else
                    p.right = x.left;
            }
        } else {
            Node m = x.right;
            while (m.left != null) {
                path.push(m);
                m = m.left;
            }
            x.key = m.key;
            x.val = m.val;
            if (x.right == m)
                x.right = m.right;
            else {
                Node p = path.peek();
                p.left = m.right;
            }
        }

        splay(x);
        return val;
    }

    private void serializeAux(Node tree, Vector<String> vec) {
        if (tree == null)
            vec.addElement(null);
        else {
            vec.addElement(tree.key.toString() + ":black");
            serializeAux(tree.left, vec);
            serializeAux(tree.right, vec);
        }
    }

    public Vector<String> serialize() {
        Vector<String> vec = new Vector<String>();
        serializeAux(root, vec);
        return vec;
    }

    void printTree(String fname) {
        Vector<String> st = serialize();
        TreePrinter treePrinter = new TreePrinter(st);
        treePrinter.fontSize = 14;
        treePrinter.nodeRadius = 14;
        try {
            FileOutputStream out = new FileOutputStream(fname);
            PrintStream ps = new PrintStream(out);
            treePrinter.printSVG(ps);
        } catch (FileNotFoundException e) {
        }
    }

    public static void main(String[] args) {
        SplaySymbolTable<Integer, Integer> table = new SplaySymbolTable<>();
        int[] keys = {1, 2, 3, 4, 9, 8, 7, 6};
        for (int i = 0; i < keys.length; i++) {
            table.insert(keys[i], keys[i]);

        }
        table.printTree("splay-tree-1.svg");
        table.search(3);
        table.search(9);
        table.search(7);
        table.printTree("splay-tree-2.svg");


        /*
            The following code provides some additional testing and uses
            the remove method, which, again, you don't need to mess with.
        !! Close the above comment to active the remaining code

        SplaySymbolTable<Integer, Integer> symtab = new SplaySymbolTable<>();
        for (int i = 0; i < 10; i++)
            symtab.insert(i, i);
        symtab.printTree("splay-insert-10.svg");

        Integer I = symtab.search(0);
        System.out.println("searched/found " + I);
        symtab.printTree("splay-search-0.svg");

        I = symtab.remove(7);
        System.out.println("removed/found " + I);
        symtab.printTree("splay-remove-7.svg");

        I = symtab.remove(1);
        System.out.println("removed/found " + I);
        symtab.printTree("splay-remove-1.svg");

        //*/
    }

}
