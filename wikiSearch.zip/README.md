# CS224-Wiki
Project completed by Grant Murray

### Initialization for Program:
Simply run "python starScript.py", with a proper installation of python on your machine.

### Star Script Program:
Scrapes wikipedia to get a random page, and works through all valid links on the page to find a path to the Star Wars
web page, with a maximum of six links deep. If Star Wars isn't found within six links deep, the program will stop and inform user.