import requests
import re
import time
from bs4 import BeautifulSoup

# Pull random page from wikipedia to use as a starting point
def get_random_page():
	r = requests.get('https://en.wikipedia.org/wiki/Special:Random')
	return r

# Removes all non-special links
def internal_not_special(href):
	if not href:
		return False # anchor isn't a link
	if not re.compile('^/wiki/').search(href):
		return False # target isn't inside wikipedia
	if re.compile('/File:').search(href):
		return False # target is a file (therefore invalid)
	if re.compile('/Category:').search(href):
		return False # target is a category (therefore invalid)
	if re.compile('/Help:').search(href):
		return False # target is a help section (therefore invalid)
	if re.compile('/Template_talk:').search(href):
		return False # target is a template talk section (therefore invalid)
	if re.compile('/Template:').search(href):
		return False # target is a template section (therefore invalid)
	if re.compile('/Portal:').search(href):
		return False # target is a portal section (therefore invalid)
	if re.compile('/Wikipedia:').search(href):
		return False # target is a wikipedia section (therefore invalid)
	if re.compile('#').search(href):
		return False # target is local to this page
	return True

# Gets random page and adds it to path
pagePath = [get_random_page()]
pageLinks = []
pageVisits = []
starFound = False

# Sets start time of program
startTime = time.time()

# Start message
print("Looking for Star Wars...\n")

# While loop to execute a DFS search algorithm
while not starFound:
	# Pull useful links from page body
	pageCurr = pagePath[-1]

	# Soupifies provided page and gets list of valid links
	pageBody = BeautifulSoup(pageCurr.text, "html.parser").find(id="bodyContent")
	pageRefs = pageBody.find_all('a', href=internal_not_special)

	# New page stack
	pageStack = []

	# Checks for star wars
	for link in pageRefs:
		link = "https://en.wikipedia.org" + link.get("href")

		# Check for star wars
		if link == "https://en.wikipedia.org/wiki/Star_Wars":
			print("Star Wars found!")
			starFound = True
			break

		# Adds page to stack
		pageStack.append(link)

	# Checks for star wars
	if starFound:
		break

	# Adds new list of links to page links
	pageLinks.append(pageStack)

	# Check depth and link list size
	if len(pagePath) == 7:
		tempLink = pagePath.pop()
		pageLinks.pop()
		pageVisits.append(tempLink)

	# Check for empty links
	if len(pageLinks[-1]) == 0:
		pageLinks.pop()
		pagePath.pop()

	# Move down links using DFS
	if len(pageLinks[-1]) > 0:
		tempLink = pageLinks[-1].pop()
		while tempLink in pageVisits and len(pageLinks[-1]) > 0:
			tempLink = pageLinks[-1].pop()
		pageVisits.append(tempLink)
		pageCurr = requests.get(tempLink)
		pagePath.append(pageCurr)

	# Checks for empty list
	else:
		pagePath.append(pageVisits[-1])
		print("These are not the links you are looking for")
		print("Could not find Star Wars from starting link\n")
		break


# Print out final page path
for page in pagePath:
	pageSoup = BeautifulSoup(page.text, "html.parser")
	pageTitle = pageSoup.find('h1', id="firstHeading").string
	print(pageTitle, "(" + page.url + ")")

# Prints out time it took to find star wars
if starFound:
	print("\nFound in:", str(round(time.time() - startTime)), "seconds")