class Connect4(object):
    
    def __init__(self, width, height, window=None):
        self.width = width
        self.height = height
        self.playturn = 'X'
        self.data = []
        
        for row in range(self.height):
            boardRow = []
            for col in range(self.width):
                boardRow += [' ']
            self.data += [boardRow]
        
    def __repr__(self):
        return self.printBoard()

    def printBoard(self):
        # Draws out board
        s = ''
        for row in range(self.height):
            s += '|'
            for col in range(self.width):
                s += self.data[row][col] + '|'
            s += '\n'
        for i in range(self.width * 2 + 1):
            s +=  '-'
        s += '\n'
        for i in range(self.width):
            s += ' ' + str(i % 10)
        s += '\n'
        return s

    def clear(self):
        # Fills all spots in data with ' '
        for row in range(self.height):
            for col in range(self.width):
                self.data[row][col] = ' '

    def isFull(self):
        # Runs through data and checks if each column has an empty spot, if not, return true
        for col in range(self.width):
            if self.allowsMove(col):
                return False
        return True

    def winsFor(self, ox):
        # Checks multiple win states by running through multiple positions of x and o
        for row in range(self.height):
            for col in range(self.width - 3):
                if self.data[row][col] == ox and \
                self.data[row][col+1] == ox and \
                self.data[row][col+2] == ox and \
                self.data[row][col+3] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width):
                if self.data[row][col] == ox and \
                self.data[row + 1][col] == ox and \
                self.data[row + 2][col] == ox and \
                self.data[row + 3][col] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row][col] == ox and \
                self.data[row + 1][col + 1] == ox and \
                self.data[row + 2][col + 2] == ox and \
                self.data[row + 3][col + 3] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row][col + 3] == ox and \
                self.data[row + 1][col + 2] == ox and \
                self.data[row + 2][col + 1] == ox and \
                self.data[row + 3][col] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row + 3][col] == ox and \
                self.data[row + 2][col + 1] == ox and \
                self.data[row + 1][col + 2] == ox and \
                self.data[row][col + 3] == ox:
                    return True

        return False


    def addMove(self, col, ox):
        # Checks if move is legal, if so, it puts a checker at the bottom of the selected column
        for i in range(self.height + 1):
            if self.allowsMove(col):
                i = -(i + 1)
                if self.data[i][col] == ' ':
                    self.data[i][col] = ox
                    break

    def delMove(self, col):
        # Checks column for space from top to bottom, if no space, add space
        for i in range(self.height):
            if self.data[i][col] != ' ':
                self.data[i][col] = ' '
                break

    def allowsMove(self, col):
        # Checks if column is full or out of bounds 
        if col < self.width and col >= 0:
            for i in range(self.height):
                if self.data[i][col] == ' ':
                    return True
        return False

    def flipTurn(self, ox):
        # Flips 'O' and 'X'
        if ox == 'O':
            return 'X'
        elif ox == 'X':
            return  'O'
 

    def hostGame(self):
        # Starts game and checks for win and game over statements 
        self.clear()
        while True:
            print(self.printBoard())
            if self.winsFor(self.flipTurn(self.playturn)):
                print(self.flipTurn(self.playturn) + ' won!')
                break
            elif self.isFull():
                print('Game over!')
                break

            print('Player turn: ' + self.playturn)
            move = int(input('Column: '))
            if self.allowsMove(move):
                self.addMove(move, self.playturn)
                self.playturn = self.flipTurn(self.playturn)
            else:
                print('Invalid move!')



def main():
    C = Connect4(11, 11)
    C.hostGame()
    


if __name__ == '__main__':
    main()