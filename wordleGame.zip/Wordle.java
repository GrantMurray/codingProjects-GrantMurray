import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;l

public class Wordle {


    private ArrayList<String> knownWords = new ArrayList<String>();
    private String secretWord;
    private Random rnd = new Random(); // a source of random numbers

    public Wordle(String file, int length, long minfreq, long maxfreq) throws IOException {
        loadWords(file, length, minfreq, maxfreq);
    }

    public Wordle(String[] words) {
        for (String word : words) {
            if (word.length() == words[0].length() && word.equals(word.toLowerCase())) {
                knownWords.add(word);
            }
        }
    }

    public int numberOfKnownWords() {
        return knownWords.size();
    }

    public void loadWords(String filenm, int length, long minfreq, long maxfreq) throws IOException {
        Scanner scan = new Scanner(new File(filenm));
        while (scan.hasNext()) {
            String word = scan.next();
            long wordFreq = scan.nextLong();
            if (word.length() == length && wordFreq >= minfreq && (wordFreq <= maxfreq || maxfreq == 0)) {
                knownWords.add(word);
            }
        }
    }

    public ArrayList<String> getKnownWords() {
        ArrayList<String> knownWordsCopy = new ArrayList<String>();
        for (String word : knownWords) {
            knownWordsCopy.add(word);
        }
        return knownWordsCopy;
    }

    public void initGame() {
        Random r = new Random();
        secretWord = knownWords.get(r.nextInt(knownWords.size()));
    }

    public Hint guess(String g) {
        int length = secretWord.length();
        if (length != g.length()) {
            throw new IllegalArgumentException("Wrong length guess!");
        }
        return new Hint(g, secretWord);
    }
}

class Hint {
    private String correctlyPlaced = "";
    private String incorrectlyPlaced = "";
    private String notInPuzzle = "";
    private String guess;

    public Hint(String guess, String secretWord) {
        String[] guessChars = guess.split("");
        String[] secretChars = secretWord.split("");
        String[] incorrectChars = new String[secretWord.length()];
        for (int i = 0; i < secretChars.length; i++) {
            if (i < guessChars.length) {
                if (secretChars[i].equals(guessChars[i])) {
                    correctlyPlaced += secretChars[i];
                }
                else {
                    correctlyPlaced += "-";
                }
            }
        }
        int notCount = 0;
        for (int j = 0; j < guessChars.length; j++) {
            incorrectChars[j] = "-";
            if (secretWord.contains(guessChars[j]) && secretChars[j].equals(guessChars[j]) == false) {
                incorrectChars[j] = guessChars[j];
            }
            else if (secretWord.contains(guessChars[j]) == false) {
                notInPuzzle += guessChars[j];
            }
        }
        incorrectlyPlaced = String.join("", incorrectChars);
    }

    public boolean isWin() {
        return (correctlyPlaced.indexOf('-') == -1);
    }

    public void write() {
        System.out.println("---- Hint (" + guess + ") ----");
        System.out.println("Correctly placed  : " + correctlyPlaced);
        System.out.println("Incorrectly placed: " + incorrectlyPlaced);
        System.out.println("Not in the puzzle : [" + notInPuzzle + "]");
    }

    public String getCorrectlyPlaced() {
        return correctlyPlaced;
    }

    public String getIncorrectlyPlaced() {
        return incorrectlyPlaced;
    }

    public String getNotInPuzzle() {
        return notInPuzzle;
    }

class Player {
    public String notInPuzzle = "";
    public String correctlyPlaced = "";
    public String incorrectlyPlaced = "";
    public String newGuess = "";
    public int wordLength = 0;

    public static void main(String[] args) throws IOException {
        int maxGuesses = 10;
        int nGuesses = 0;

        String[] shortlist = {"state", "tacks"};
        Wordle puzzle = new Wordle("norvig200.txt", 5, 100000, 0);

        puzzle.initGame();

        System.out.print("Your guess: ");
        Scanner scan = new Scanner(System.in);

        Hint h = null;
        while(scan.hasNext() && nGuesses < maxGuesses) {
            nGuesses += 1;
            String token = scan.next();
            System.out.println("  Got: '" + token + "'");
            try {
                h = puzzle.guess(token);
                h.write();
                if ( h.isWin() ) {
                    System.out.println("You won in " + nGuesses + " moves!");
                    break;
                }
            }
            catch (IllegalArgumentException e) {
                System.out.println("... try again...");
                nGuesses -= 1;
            }
            System.out.print("Your guess: ");
        }
        if (!h.isWin()) {
            System.out.println("Too many moves!  You lose!");
        }
    }
    
    
}