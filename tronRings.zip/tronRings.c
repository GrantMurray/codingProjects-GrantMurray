/*
Name: Grant Murray
Course: CS 261
Date: 1/23/2023
Compile Instructions: gcc -Wall -std=c99 -pedantic -o prog1 prog1.c
Program Description: Generates a tron ring based on core size and ring amount
    provided by the user.
*/

#include <stdio.h>

int main() {
    // Declares new variables coreSize and ringNum
    int coreSize, ringNum;

    // Loops until coreSize and ringNum is zero
    while (1==1) {

        coreSize = -1;
        ringNum = -1;

        // Loops until you give proper input for coreSize and ringNum
        while (coreSize < 0 || ringNum < 1) {
            // Gets user input for coreSize and ringNum
            printf("\nRings: ");
            scanf("%d", &ringNum);
            printf("Core Size: ");
            scanf("%d", &coreSize);

            // Returns if coreSize and ringNum are zero
            if (coreSize == 0 && ringNum == 0) {
                return 0;
            }

            // Checks to see if coreSize is less than zero
            if (ringNum < 1) {
                printf("Improper input for Rings\n");
            }
            if (coreSize < 0) {
                printf("Improper input for Core Size\n");
            }
        }

        // Prints out top layer of rings
        for (int ii = ringNum; ii >= 1; ii--) {
            // Spaces
            for (int jj = ii; jj > 1; jj--) {
                printf(" ");
            }
            // Forward slashes
            for (int jj = ii; jj <= ringNum; jj++) {
                printf("/");
            }
            // Lines
            for (int jj = 0; jj < coreSize; jj++) {
                printf("-");
            }
            // Back slashes
            for (int jj = ii; jj <= ringNum; jj++) {
                printf("\\");
            }
            printf("\n");
        }

        // Prints out core
        for (int ii = coreSize; ii >= 1; ii--) {
            // Left lines
            for (int jj = 0; jj < ringNum; jj++) {
                printf("|");
            }
            // Dots
            for (int jj = 0; jj < coreSize; jj++) {
                printf(" ");
            }
            // Right lines
            for (int jj = 0; jj < ringNum; jj++) {
                printf("|");
            }
            printf("\n");
        }

        // Prints out bottom layer of rings
        for (int ii = 1; ii <= ringNum; ii++) {
            // Spaces
            for (int jj = ii; jj > 1; jj--) {
                printf(" ");
            }
            // Back slashes
            for (int jj = ii; jj <= ringNum; jj++) {
                printf("\\");
            }
            // Lines
            for (int jj = 0; jj < coreSize; jj++) {
                printf("-");
            }
            // Forward slashes
            for (int jj = ii; jj <= ringNum; jj++) {
                printf("/");
            }
            printf("\n");
        }
    }
}
