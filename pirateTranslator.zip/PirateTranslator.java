public class PirateTranslator {

    String[] phrases = {"hello", "hi", "is", "pardon me", "excuse me",
			"my", "friend", "sir", "madam",
			"stranger", "officer",
			"where", "you", "tell",
			"know", "how far", "old", "happy"};
    String[] piratetalk = {"ahoy", "yo-ho-ho", "be", "avast", "arrr",
			   "me", "me bucko", "matey", "proud beauty",
			   "scurvy dog", "foul blaggart",
			   "whar", "ye", "be tellin'",
			   "be knowin'", "how many leagues",
			   "barnacle-covered", "grog-filled"};
	
    String[] positiveWords = {"adore", "enjoy", "love"};
    String[] negativeWords = {"hate", "despise", "dislike"};
    
    String[] lastTranslations = new String[25];
    int s = 0;

    public String translate(String input) {
		input = input.toLowerCase();
		input = input.replace("dislike", "dblike");
		input = input.replace("despise", "denim");
		for(String phrase : phrases) {
			input = input.replace(phrase, piratetalk[s]);
			s++;
		}
		input = input.replace("dblike", "dislike");
		input = input.replace("denim", "despise");
		s = 0;
		for(String neg : negativeWords) {
			for (String pos : positiveWords) {
				if (input.contains(neg) && input.contains(pos)) {
					return input;
				}
			}
		}
		for(String pos : positiveWords) {
			if (input.contains(pos)) {
				input += " 'tis like me pirate treasure!";
			}
		}
		for(String neg : negativeWords) {
			if (input.contains(neg)) {
				input += " 'tis like bein' food for the fish!";
			}
		}
	return input;
    }
}