#!/bin/bash
set -e
set -o errtrace

trap 'err_report' ERR

TARGET=${1:-run}

# driver.sh - The simplest autograder using JUnitTests.
#   Usage: ./driver.sh

err_report() {
    ERR_CODE=$?
    echo "Error! ($ERR_CODE)"
    echo "{\"scores\": {\"Correctness\": 0}}"
    exit 0
}

# Compile the code

echo "Verifying submission"
make --no-print-directory verify

echo "Cleaning..."
make --no-print-directory clean

echo "Compiling..."
rm -rf ${BUILD}
make --no-print-directory bin

echo "Running..."
make --no-print-directory ${TARGET}

exit 0
