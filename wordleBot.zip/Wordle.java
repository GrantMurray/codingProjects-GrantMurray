import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * The puzzle game 'Wordle'!
 *
 * Basic idea:
 * the game loads in a set of 'known words' from a file or an array.
 * All 'known words' must have the same length (e.g., 5 characters)
 *
 * When the game starts, a secret word is chosen from the list of known words.
 * The player can then issue guesses.
 * Each guess returns a Hint object instance that tells:
 * - which characters in the guess are correct, and correctly located.
 * - which characters in the guess are in the secret word, but not at the location guessed
 * - which characters in the guess are not in the secret word
 *
 * If all characters in the guess are correctly located, the game is won ;)
 */
public class Wordle {


    private ArrayList<String> knownWords = new ArrayList<String>();
    private String secretWord;
    private Random rnd = new Random(); // a source of random numbers

    /**
     * Create a new Wordle game, loading allowable words from a file.
     * See comments on loadWords() for the file format.
     *
     * @param file    - the file from which to load 'known words'
     * @param length  - the minimum length word
     * @param minfreq - the minimum allowed frequency
     * @param maxfreq - the maximum allowed frequency
     */
    public Wordle(String file, int length, long minfreq, long maxfreq) throws IOException {
        // ~12K 5 letter words with min frequency of 100,000
        loadWords(file, length, minfreq, maxfreq);
    }

    /**
     * Loads all words from array, and tests to see if their length is equal to that of the length 
     * provided, and also that they are lowercase, if these conditions are true, then it
     * adds them to the list knownWords.
     *
     * @param words - an array of words to load
     */
    public Wordle(String[] words) {
        for (String word : words) {
            if (word.length() == words[0].length() && word.equals(word.toLowerCase())) {
                knownWords.add(word);
            }
        }
    }

    public int numberOfKnownWords() {
        return knownWords.size();
    }

    /**
     * Searches through each line in the file and adds each individual string if they meet
     * the following criteria; they are of length given, and their frequency is within
     * the given min and max frequency values.
     *
     * @param filenm  - the file name to load from
     * @param length  - the length of words we want to load (e.g., 5 to load 5 character words)
     * @param minfreq - the minimum allowable frequency for a loaded word
     * @param maxfreq - the maximum allowable frequenct for a loaded word; 0 indicates no maximum
     */
    public void loadWords(String filenm, int length, long minfreq, long maxfreq) throws IOException {
        Scanner scan = new Scanner(new File(filenm));
        while (scan.hasNext()) {
            String word = scan.next();
            long wordFreq = scan.nextLong();
            if (word.length() == length && wordFreq >= minfreq && (wordFreq <= maxfreq || maxfreq == 0)) {
                knownWords.add(word);
            }
        }
    }

    /**
     * Creates new string array called knownWordsCopy, and goes through
     * everything in knownWords and adds everything to the copy, 
     * finnaly, returns the copy.
     *
     * @return a new copy of list of known words.
     */
    public ArrayList<String> getKnownWords() {
        ArrayList<String> knownWordsCopy = new ArrayList<String>();
        for (String word : knownWords) {
            knownWordsCopy.add(word);
        }
        return knownWordsCopy;
    }

    /**
     * Prepare the game for playing by choosing a new secret word.
     */
    public void initGame() {
        Random r = new Random();
        secretWord = knownWords.get(r.nextInt(knownWords.size()));
    }

    /**
     * Supply a guess and get a hint!
     *
     * Note that this implementation DOES NOT require that the guess be selected
     * from the known words. Rather, this implementation allows one to guess arbitrary
     * characters, so long as the guess is the same length as the secret word.
     *
     * @param g - the guess (a string which is the same length as the secret word)
     * @return a hint indicating the letters guessed correctly/incorrectly
     * @throws IllegalArgumentException if the guess is not the same length as the secret word
     */
    public Hint guess(String g) {
        int length = secretWord.length();
        if (length != g.length()) {
            throw new IllegalArgumentException("Wrong length guess!");
        }
        return new Hint(g, secretWord);
    }

    public static void main(String[] args) throws IOException {
        int maxGuesses = 10;
        int nGuesses = 0;

        String[] shortlist = {"state", "tacks"};
        Wordle puzzle = new Wordle("norvig200.txt", 5, 100000, 0);

        puzzle.initGame();

        System.out.print("Your guess: ");
        Scanner scan = new Scanner(System.in);

        Hint h = null;
        while(scan.hasNext() && nGuesses < maxGuesses) {
            nGuesses += 1;
            String token = scan.next();
            System.out.println("  Got: '" + token + "'");
            try {
                h = puzzle.guess(token);
                h.write();
                if ( h.isWin() ) {
                    System.out.println("You won in " + nGuesses + " moves!");
                    break;
                }
            }
            catch (IllegalArgumentException e) {
                System.out.println("... try again...");
                nGuesses -= 1;
            }
            System.out.print("Your guess: ");
        }
        if (!h.isWin()) {
            System.out.println("Too many moves!  You lose!");
        }
    }

}

/**
 * NOTE:
 *
 * We're breaking one of our initial rules about Java.
 * The truth is...more than one class CAN live in a file.
 *
 * However, only one public class can live in a file.
 * The Hint class below is not public.
 *
 * Style-wise, Hint would probably be best as a public class
 * because the intent is for it to be used widely. However,
 * that makes submission to autolab much more complicated.
 * And as a result, I have opted to keep it in the same file
 * as the Wordle class itself.
 */
class Hint {
    // why private?
    // because we want the hint to be generated by the constructor and then
    // not messed with further. So, we restrict access to these variables.
    private String correctlyPlaced = "";
    private String incorrectlyPlaced = "";
    private String notInPuzzle = "";
    private String guess;

    /**
     * Sorts through the secret word and searches guess
     * for characters with the same value and position,
     * if they do exist, place them in correctlyPlaced, and if not
     * insert a "-" character instead, secondly, it sorts through
     * guesses and searches to see if they are both not correctly
     * placed and in the secret word, and adds them to their respective
     * position with respect to guess, and if not places "-" again.
     *
     * @param guess
     * @param secretWord
     */
    public Hint(String guess, String secretWord) {
        String[] guessChars = guess.split("");
        String[] secretChars = secretWord.split("");
        String[] incorrectChars = new String[secretWord.length()];
        for (int i = 0; i < secretChars.length; i++) {
            if (i < guessChars.length) {
                if (secretChars[i].equals(guessChars[i])) {
                    correctlyPlaced += secretChars[i];
                }
                else {
                    correctlyPlaced += "-";
                }
            }
        }
        int notCount = 0;
        for (int j = 0; j < guessChars.length; j++) {
            incorrectChars[j] = "-";
            if (secretWord.contains(guessChars[j]) && secretChars[j].equals(guessChars[j]) == false) {
                incorrectChars[j] = guessChars[j];
            }
            else if (secretWord.contains(guessChars[j]) == false) {
                notInPuzzle += guessChars[j];
            }
        }
        incorrectlyPlaced = String.join("", incorrectChars);
    }

    public boolean isWin() {
        // true iff the '-' isn't in the correctlyPlaced String...
        return (correctlyPlaced.indexOf('-') == -1);
    }

    /**
     * Display a hint on System.out
     *
     * Given a secret word: 'state', and a guess 'scope' display:
     *
     * ---- Hint (scope) ----
     * Correctly placed  : s---e
     * Incorrectly placed: -----
     * Not in the puzzle : [cop]
     *
     * Given a secret word: 'state', and a guess 'sttae' display:
     *
     * ---- Hint (scope) ----
     * Correctly placed  : st--e
     * Incorrectly placed: --ta-
     * Not in the puzzle : []
     */
    public void write() {
        System.out.println("---- Hint (" + guess + ") ----");
        System.out.println("Correctly placed  : " + correctlyPlaced);
        System.out.println("Incorrectly placed: " + incorrectlyPlaced);
        System.out.println("Not in the puzzle : [" + notInPuzzle + "]");
    }

    /**
     * Note that we can return a reference to the correctlyPlaced String
     * safely since String's aren't immutable.  Thus, someone that messes
     * with the result we return won't actually impact the String
     * referenced by the Hint itself...
     *
     * @return the correctly placed portion of the hint
     */
    public String getCorrectlyPlaced() {
        return correctlyPlaced;
    }

    /**
     *
     * @return the incorrectly placed portion of the hint
     */
    public String getIncorrectlyPlaced() {
        return incorrectlyPlaced;
    }

    /**
     *
     * @return the not-in-puzzle portion of the hint
     */
    public String getNotInPuzzle() {
        return notInPuzzle;
    }
}