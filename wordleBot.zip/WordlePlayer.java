/**
 * Grant Murray
 * Strategy of bot:
 * My bot starts by loading legal words, and then putting those words into a list.
 * It then starts with the first word in the list as a hint (good because it has an a in it)
 * and checks for words in the list that have matching characters as the hint. If none, it makes
 * a random guess, if so, it picks a random word with matching characters. Every time it
 * makes a guess it removes previous guesses from legal words as to work to an endpoint.
 * Not the most efficient system, but it does work nonetheless. 
 */




import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public interface WordlePlayer {
    
    /**
     * Called prior to starting a game, to allow the player to fetch legal words
     * from the game instance.
     *
     * @param game
     */
    public void beginGame(Wordle game);
        
    /**
     *
     * @return true if a player can make a guess.
     */
    public boolean hasNextGuess();

    /**
     *
     * @return the player's next guess.
     */
    public String nextGuess();

    /**
     * Called by the 'game loop' to communicate a hint from the game instance
     * to the player.
     *
     * @param h
     */
    public void tell(Hint h);

}

public class DumbBot {

    /**
     * Creates new string array for guessed words by the bot
     */
    private ArrayList<String> guessedWords = new ArrayList<String>();

    public void Dumbot(Wordle game) {
        game.gameinit();
    }
    /**
     * Starts game by loading paramaters legal words, the length of legal words, and a 
     * baseline hint variable. 
     */
    public void beginGame(Wordle game) {
        ArrayList<String> legalWords = game.knownWords;
        int lengthWord = game.knownWords[1].length;
        String hint = "";
        for (int i; i < lengthWord; i++) {
            hint += "-";
        }
    }

    /**
     * Checks to see if the length of legal words is greater than 0,
     * I.E. there are still legal words to guess.
     */
    public boolean hasNextGuess() {
        if (legalWords.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * Creates next guess by sorting through legal words and finding ones that have
     * matching letters, then picks random one and removes old candidates from list.
     */
    public String nextGuess() {
        if (guessedWords.size() == 0) {
            String guess = legalWords[1];
            guessedWords.add(guess);
            return guess;
        }
        else {
            ArrayList<String> guesses = new ArrayList<String>();
            String guess = "";
            for (int i : lengthWord) {
                if (hint[i].equals("-") == false) {
                    for (String word : legalWords) {
                        if (word[i].equals(hint[i])) {
                            legalWords.remove(word);
                            guesses.add(word);
                        }
                    }
                }
            }
        }
        return guesses[randomInt(guesses.length())];
    }

    // Sets string hint to given hint.
    public void tell (Hint h) {
        String hint = h;
    }
        
}