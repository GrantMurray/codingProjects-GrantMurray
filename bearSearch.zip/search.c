#include <stdio.h>
#include "search.h"

int sentenceInput(SearchResults* inputStruct) {
    // Declares variables needed for this loop
    char tempSentence[101];
    char tempMessageID[21];

    // Gets message input from user and clears input stream
    printf("Message: ");
    fgets(tempSentence,101,stdin);
    if (ftell(stdin) == 100) {
        while (getchar() != '\n');
    }

    // Removes newline from string and checks if ;done; was typed, moves it into struct
    tempSentence[strcspn(tempSentence, "\n")] = 0;
    if (strcmp(tempSentence,";done;") == 0) return 2;
    strcpy(inputStruct->sentence, tempSentence);

    // Gets ID input from user and clears input stream
    printf("ID: ");
    fgets(tempMessageID,21,stdin);
    if (ftell(stdin) == 20) {
        while (getchar() != '\n');
    }

    // Removes newline from string and checks if ;done; was typed, moves it into struct
    tempMessageID[strcspn(tempMessageID, "\n")] = 0;
    if (strcmp(tempMessageID,";done;") == 0) return 2;
    strcpy(inputStruct->messageID, tempMessageID);

    // Spare newline
    printf("\n");

    // If either message input or message id input is empty, returns negative number
    if (strlen(tempSentence) == 0 | strlen(tempMessageID) == 0) return -1;

    return 1;
}

void wordScan(SearchResults* inputStruct) {
    // Declares string arrays containing bear and food words
    char bearArray[5][8] = {"bear", "teddy", "panda", "grizzly", "berry"};
    char foodArray[5][8] = {"honey", "berries", "huckle", "nectar", "fish"};

    // Initializes alertLevel and numWordsFound to 0, and wordsOfInterest to ""
    inputStruct->alertLevel = 0;
    inputStruct->numWordsFound = 0;
    strcpy(inputStruct->wordsOfInterest, "");

    // Declares food alert and bear alert
    int bearAlert = 0;
    int foodAlert = 0;

    // Searches array for bear words
    for (int ii = 0 ; ii < 5 ; ii++) {
        // Initializes bearWord and stringTester
        char *bearWord = bearArray[ii];
        char *stringTester = strstr(inputStruct->sentence, bearWord);

        // Tests if string tested is NULL (aka it doesn't exist in the array)
        if (stringTester != NULL) {
            strcat(inputStruct->wordsOfInterest, bearWord);
            strcat(inputStruct->wordsOfInterest, " ");
            bearAlert = 1;
            ++inputStruct->numWordsFound;
        }
    }

    // Searches array for food words
    for (int ii = 0 ; ii < 5 ; ii++) {
        // Initializes bearWord and stringTester
        char *foodWord = foodArray[ii];
        char *stringTester = strstr(inputStruct->sentence, foodWord);

        // Tests if string tested is NULL (aka it doesn't exist in the array)
        if (stringTester != NULL) {
            strcat(inputStruct->wordsOfInterest, foodWord);
            strcat(inputStruct->wordsOfInterest, " ");
            foodAlert = 1;
            ++inputStruct->numWordsFound;
        }
    }

    // Sets alert level
    if (foodAlert == 1 && bearAlert == 1) inputStruct->alertLevel = 2;
    else if (foodAlert == 1 || bearAlert == 1) inputStruct->alertLevel = 1;
    else inputStruct->alertLevel = 0;
}

void messagePrint(SearchResults* inputStruct) {
    printf("sentence: %s\n", inputStruct->sentence);
    printf("wordsofInterest: %s\n", inputStruct->wordsOfInterest);
    printf("alertLevel: %i\n", inputStruct->alertLevel);
    printf("numofWords: %i\n\n", inputStruct->numWordsFound);
}