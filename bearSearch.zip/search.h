#ifndef PROG2_SEARCH_H
#define PROG2_SEARCH_H
#endif //PROG2_SEARCH_H

#include <string.h>

typedef struct SEARCHRESULTS{
    char messageID[21];
    char sentence[101];
    char wordsOfInterest[65];
    short int alertLevel;
    short int numWordsFound;
} SearchResults;

int sentenceInput(SearchResults* inputStruct);
void wordScan(SearchResults* inputStruct);
void messagePrint(SearchResults* inputStruct);