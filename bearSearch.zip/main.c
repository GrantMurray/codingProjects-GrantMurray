#include <stdio.h>
#include "search.h"

/*
Name: Grant Murray
Course: CS 261
Date: 2/14/2023
Compile Instructions:
 * Cd into file containing your makefile
 * Run the make command
Program Description:
 * Takes in sentences from user input and finds bear or food words, and gives out
 * respective output in the form of the sentence you typed, the alert level, and the
 * number of bear or food words found
*/

int main() {
    // Beginning message
    printf("|   Enter up to 10 messages each with an accompanying message ID    |\n");
    printf("|   Messages can be 100 characters long, and message ID can be 20   |\n");
    printf("|          You can also end your input by typing ;done;             |\n\n");

    // Declares new struct array and return variable
    SearchResults inputArray[10];

    // Sets all alert levels to zero (strange bug I had)
    for (int ii = 0 ; ii < 10 ; ii++) {
        inputArray[ii].alertLevel = 0;
    }

    // Loops to fill up inputArray with input from the user
    for (int ii = 0 ; ii < 10 ; ii++) {
        // Prints out top line fluff
        printf("-- %i --\n", ii+1);

        // Initializes new struct and updates it with user input
        SearchResults inputStruct;
        int sentenceReturn = sentenceInput(&inputStruct);

        // Tests on return value
        if (sentenceReturn < 0) return 0;
        if (sentenceReturn == 2 && ii == 0) return 0;
        if (sentenceReturn == 2) break;

        // Runs wordScan
        wordScan(&inputStruct);

        // Adds struct into struct array
        inputArray[ii] = inputStruct;
    }

    // Declares alertTwo and alertOne variables
    int alertTwo;
    int alertOne;

    // Prints out alert level two messages
    printf("\n-- ALERT LEVEL 2 --\n\n");
    for (int ii = 0 ; ii < 10 ; ii++) {
        // Declares new struct to test
        SearchResults inputStruct = inputArray[ii];

        // Checks if struct is alert level two, if so, send it to messagePrint
        if (inputStruct.alertLevel == 2) {
            messagePrint(&inputStruct);
            alertTwo = 1;
        }
    }

    // Prints out none if there are no alert level twos
    if (alertTwo != 1) {
        printf("NONE\n\n");
    }

    // Prints out alert level one messages
    printf("-- ALERT LEVEL 1 --\n\n");
    for (int ii = 0 ; ii < 10 ; ii++) {
        // Declares new struct to test
        SearchResults inputStruct = inputArray[ii];

        // Checks if struct is alert level one, if so, send it to messagePrint
        if (inputStruct.alertLevel == 1) {
            messagePrint(&inputStruct);
            alertOne = 1;
        }
    }

    // Prints out none if there are no alert level ones
    if (alertOne != 1) {
        printf("NONE\n\n");
    }

    // Bottom text
    printf("-------------------\n");

    return 0;
}