public class MoveToFrontList {

	private StringCountElement head; // the head reference
	private StringCountElement tail; // the tail reference
	private int size; // the size of the list (number of valid items)

	public MoveToFrontList() {
		// Does nothing
	}

	public int incrementCount(String key) {
		StringCountElement s = find(key);
		if (s != null) {
			// found the key, splice it out and increment the count
			spliceOut(s);
			s.count++;
		} else {
			// need to create a new element
			s = new StringCountElement();
			s.key = key;
			s.count = 1;
		}
		// move it to the front
		spliceIn(s, 0);
		return s.count;
	}

	public int size() {
		return size;
	}

	public StringCountElement find(String key) {
		StringCountElement list = head;
		while (list != null) { // Loops through list, if not null and key not null check for string
			if (list.key != null) {
				if (list.key.equals(key)) {
					return list;
				}
			}
			list = list.next;
		}
		return null;
	}

	public int rank(String key) {
		StringCountElement list = head;
		for (int i = 0; i < size; i++) { // Loops through list, and checks for key, returns count if found
			if (list.key.equals(key)) {
				return i;
			}
			list = list.next;
		}
		return size;
	}

	public void spliceIn(StringCountElement s, int desiredRank) {
		if (size == 0) { // If size 0, head is now s
			head = s;
		}
		else if (size == 1 && desiredRank == 1) { // If size 1, and desired 1, tail is now s
			tail = s;
		}
		else {
			StringCountElement place = head;

			if (desiredRank == 0) { // Splice in head
				head = s;
				head.next = place;
				place.prev = head;
			}
			else if (desiredRank >= size) { // Splice in tail
				for (int i = 0; i < size - 1; i++) {
					place = place.next;
				}
				place.next = s;
				s.prev = place;
				tail = s;
			}
			else { // Splice in middle
				for (int i = 0; i < desiredRank; i++) {
					place = place.next;
				}
				place.prev.next = s;
				s.prev = place.prev;
				s.next = place;
				place.prev = s;
			}
		}

		size++;
		return;
	}

	public void spliceOut(StringCountElement s) {
		if (size == 1) { // If size is 1, remove head
			head = null;
			size--;
		}
		if (head == null) { // There is nothing in the list, do nothing
			return;
		}

		if (s.next != null && s.prev != null) { // If mid case, remove s
			s.prev.next = s.next;
			s.next.prev = s.prev;
		}
		else if (s.prev == null) { // If head case, remove s and make new head
			s.next.prev = null;
			head = s.next;
		}
		else if (s.next == null) { // If tail case, remove s and make new tail
			s.prev.next = null;
			tail = s.prev;
		}
		s.next = null;
		s.prev = null;
		size--;
		return;
	}
}
