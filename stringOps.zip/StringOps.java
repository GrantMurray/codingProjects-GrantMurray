public class StringOps {
    int counts;

    /**
     * Starts from beginning of list
     * and works its way to the end 
     * searching for specific variable
     * in this case query
     */
    public int linearSearch(String[] array, String query, int l, int r) {
        for (int i = l; i < r; i++) {
            if (array[i].equals(query)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Checks beginning of array for 
     * query, and if not, splits it into 
     * subsections and repeats until
     * the lower bound is equal to the upper
     */
    public int binarySearch(String[] sortedArray, String query, int l, int r) {
        if (sortedArray[l].equals(query)) {
            return l;
        }
        if (l < r) {
            return binarySearch(sortedArray, query, l + 1, r);
        }
        return -1;
    }

    /**
     * Swaps variables in list starting from
     * the beginning and looping back around
     * until the whole list is sorted
     */
    public void swapemSort(String[] array) {
        int i = 0;
        while (i < array.length - 1) {
            i++;
            if ((int) array[i-1].charAt(0) > (int) array[i].charAt(0)) {
                String a = array[i-1];
                array[i-1] = array[i];
                array[i] = a;
                i = 0;
            }
        }
        return;
    }

    /**
     * Checks value of variable and inserts it
     * in the propper positoin
     */
    public void insertSort(String[] array) {
        for (int i = 1; i < array.length; i++) {
            String a = array[i];
            int j = 0;
            for (j = i - 1; j >= 0 && (int) a.charAt(0) < (int) array[j].charAt(0); j--) {
                array[j+1] = array[j];
            }
            array[j+1] = a;
        }
        return;
    }

    /**
     * Creates new array that is the combined
     * length of array1 and array2 and names it
     * array3, then it adds all values from array1
     * to array3 and then goes through array2 and
     * adds unique values from array2 to array3 at
     * their appropriate positions, finally, it goes
     * through array3 and counts all values that aren't
     * nothing, and increments len, then from len, a 
     * new array, array4, is created, and all values
     * from array3 that aren't nothing to array4, then
     * it returns array4
     */
    public static String[] union(String[] array1, String[] array2) {
        String[] array3 = new String[array1.length + array2.length];
        for (int i = 0; i < array1.length; i++) {
            array3[i] = array1[i];
        }
        for (int i = 0; i < array2.length; i++) {
            int add = 1;
            for (int j = 0; j < array1.length; j++) {
                if (array2[i].equals(array1[j])) {
                    add = 0;
                }
            }
            if (add > 0) {
                array3[array1.length + i] = array2[i];
            }
        }
        int len = 0;
        for (int i = 0; i < array3.length; i++) {
            if (array3[i] != null) {
                len++;
            }
        }
        String[] array4 = new String[len];
        int pos = 0;
        for (int i = 0; i < array3.length; i++) {
            if (array3[i] != null) {
                array4[pos] = array3[i];
                pos++;
            }
        }
        return array4;
    }

    /**
     * Determines the length of the shortest array and
     * sets it to num1, then finds length of second array
     * and sets it to num2, then it creates a new array named
     * array3 that is length num1, then it goes through array3
     * and adds all unique items from array1 that are also in 
     * array2, after all that it sorts through array3 removing
     * all nulls and returns array4, which is the final result
     */
    public static String[] intersection(String[] array1, String[] array2) {
        int num1 = 0;
        int num2 = 0;
        if (array1.length < array2.length) {
            num1 = array1.length;
            num2 = array2.length;
        }
        else {
            num1 = array2.length;
            num2 = array1.length;
        }
        String[] array3 = new String[num1];
        for (int i = 0; i < num1; i++) {
            int add = 0;
            for (int j = 0; j < num2; j++) {
                if (num1 == array1.length) {
                    if (array1[i].equals(array2[j])) {
                        add = 1;
                    }
                }
                else if (num2 == array2.length) {
                    if (array2[i].equals(array1[j])) {
                        add = 1;
                    }
                }
            }
            for (int j = 0; j < num1; j++) {
                if (num1 == array1.length) {
                    if (array1[i].equals(array3[j])) {
                        add = 0;
                    }
                }
                else if (num2 == array2.length) {
                    if (array2[i].equals(array3[j])) {
                        add = 0;
                    }
                }
            }
            if (add > 0 && num1 == array1.length) {
                array3[i] = array1[i];
            }
            else if (add > 0 && num1 == array2.length) {
                array3[i] = array2[i];
            }
        }
        int len = 0;
        for (int i = 0; i < array3.length; i++) {
            if (array3[i] != null) {
                len++;
            }
        }
        String[] array4 = new String[len];
        int pos = 0;
        for (int i = 0; i < array3.length; i++) {
            if (array3[i] != null) {
                array4[pos] = array3[i];
                pos++;
            }
        }
        return array4;
    }

    /**
     * Uncomment code below to test intersection
     */
    // public static void main(String[] args) {
    //     String[] array1 = {"the", "when", "the"};
    //     for (String n : array1) {
    //         System.out.println(n);
    //     }
    //     System.out.println("-------");
    //     String[] array2 = {"how", "the", "when", "why", "boof"};
    //     for (String n : array2) {
    //         System.out.println(n);
    //     }
    //     System.out.println("-------");
    //     String[] array3 = intersection(array1, array2);
    //     for (String n : array3) {
    //         System.out.println(n);
    //     }
    // }
    /**
     * Uncomment code below to test union
     */
    // public static void main(String[] args) {
    //     String[] array1 = {"the", "when", "the"};
    //     for (String n : array1) {
    //         System.out.println(n);
    //     }
    //     System.out.println("-------");
    //     String[] array2 = {"how", "the", "when", "why", "boof"};
    //     for (String n : array2) {
    //         System.out.println(n);
    //     }
    //     System.out.println("-------");
    //     String[] array3 = union(array1, array2);
    //     for (String n : array3) {
    //         System.out.println(n);
    //     }
    // }
}
