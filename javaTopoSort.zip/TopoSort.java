import java.sql.Array;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class TopoSort {

    /**
     * Part 1: Implement this
     *
     * Function to perform topological sort on a given Graph object.
     *
     * If a topological ordering exists, return it.
     * Other return null if:
     *      passed a null
     *      passed a graph with < 1 vertex
     *      passed a graph containing cycles
     *
     * Note that undirected graphs won't have topological orderings,
     * but you do not need to explicitly check for that.
     *
     * @param g A graph to be sorted, or null
     * @return  An iterable object with the ordering, or null
     */
    public static Iterable<Integer> sort(Graph g) {
        if (g == null) {
            return null;
        }
        else if (g.numVertices < 1) {
            return null;
        }

        int[] inbound = new int[g.numVertices];
        Queue<Integer> storageQ = new LinkedList<>();
        ArrayList<Integer> sortedOutput = new ArrayList<>();

        for (int v = 0; v < g.numVertices; v++) {
            for (int u : g.adj(v)) {
                inbound[u] = inbound[u] + 1;
            }
        }

        for (int v = 0; v < g.numVertices; v++) {
            if (inbound[v] == 0) {
                storageQ.add(v);
            }
        }

        while (storageQ.size() > 0) {
            int v = storageQ.remove();
            sortedOutput.add(v);
            for (int u: g.adj(v)) {
                inbound[u] = inbound[u] - 1;
                if (inbound[u] == 0) {
                    storageQ.add(u);
                }
            }
        }
        if (sortedOutput.size() == g.numVertices) {
            return sortedOutput;
        }
        return null;
    }
}