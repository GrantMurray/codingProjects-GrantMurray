def backupFile(inputFile, outputFile):
    # Reads input file and writes to output file set to .bak the contents of the input
    with open(inputFile, 'r') as f: 
        with open(outputFile + '.bak', 'w') as o:
            o.write(f.read())

def addSemester(inputFile, outputFile):
    # Checks every line for membership in either springCS or fallCS and if so
    # adds spring or fall respectively
    fallCS = ['cs 121', 'cs 223', 'cs 215', 'cs 260']
    springCS = ['cs 122', 'cs 166', 'cs 224', 'cs 251', 'cs 261']
    with open(inputFile, 'r') as f:
        with open(outputFile, 'w') as o:
            for line in f:
                line = line.strip()
                if line in fallCS:
                    o.write(line + ' fall\n')
                elif line in springCS:
                    o.write(line + ' spring\n')

def reverseLine(inputFile, outputFile):
    # Opens input file and writes to output file each line from input but reversed
    with open(inputFile, 'r') as f:
        with open(outputFile, 'w') as o:
            for line in f:
                line = line.strip().split()
                reverse = [line[len(line) - i - 1] for i in range(len(line))]
                o.write(' '.join(reverse) + '\n')

def storeTabDelimitedFile(inputFile):
    # Deliminates file and stores it in a 2d list
    with open(inputFile, 'r') as f:
        return [line.split('\t') for line in f]

def main():
    backupFile('classes.txt', 'backup.bak')
    addSemester('classes.txt', 'semester.txt')
    reverseLine('classes.txt', 'out.txt')
    print(storeTabDelimitedFile('out.txt'))


if __name__ == '__main__':
    main()
