#!/bin/bash

# Checks if two variables were passed into program
if [ $# -ne 2 ]; then
	echo "Improper number of inputs"
	exit 1
fi

# Checks if file one is valid
if [ ! -r $1 ]
then
	echo "Invalid input for file one"
	exit 1
fi

# Checks if file two is valid
if [ ! -r $2 ]
then
	echo "Invalid input for file two"
	exit 1
fi

# Loads alice in wonderland text lowercase and all letters
alicetext=$(cat $1 | tr '[:upper:]' '[:lower:]' | tr -cd '[:alpha:]\n ' | grep -Eo -e '[a,i,o]{1}' -e '[a-z]{2,}')

# Moves alice text into a word array deliminated by space
alicewords=($alicetext)

# Prints out initial text
echo "^^^ ^^ ^" ${alicewords[0]} >> $2
echo "^^^ ^^" ${alicewords[0]} ${alicewords[1]} >> $2
echo "^^^" ${alicewords[0]} ${alicewords[1]} ${alicewords[2]} >> $2
echo ${alicewords[0]} ${alicewords[1]} ${alicewords[2]} ${alicewords[3]} >> $2

# Loops through alicewords and prints out all 4 word sequences
for (( i=1; i<${#alicewords[@]}-3; i++ ));
do
	echo ${alicewords[i]} ${alicewords[i+1]} ${alicewords[i+2]} ${alicewords[i+3]} >> $2
done