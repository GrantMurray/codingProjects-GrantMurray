#!/bin/bash

# Checks if two variables were passed into program
if [ $# -ne 2 ]; then
	echo "Improper number of inputs"
	exit 1
fi

# Checks if file is valid
if [ ! -r $1 ]
then
	echo "Invalid file input"
	exit 1
fi

# Checks if integer input is valid
if [[ $2 =~ [^0-9] ]] || [[ $2 -lt '1' ]]
then
	echo "Invalid number input"
	exit 1
fi

# Initializes shuf program
shuf=$(command -v shuf)
	if [ ! -x "$shuf" ]; then
		if [ -x "./shuffle" ]; then
			shuff="./shuffle"
	else
		echo "No shuffle program!" 1>& 2
		exit -1
	fi
fi

# Shuffles file lines and gets first three words
line=$($shuf < $1 | sed 's/[^ ]* *//' | head -n 1)
line=($line)

# Prints out first line
echo -n "${line[*]} "

# Loops for length of requested sentence
for (( i=3; i<$2; i++ ));
do
	word=$(grep "^${line[*]}*" $1 | head -n 1) >> $1
	word=$($shuf < $1 | sed 's/.* //' | head -n 1)
	line=(${line[1]} ${line[2]} ${line[3]} $word)
	echo -n "$word "
done

# Final newline
echo -e "\n"