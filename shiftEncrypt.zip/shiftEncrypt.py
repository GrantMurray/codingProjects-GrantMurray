from letprob import *

class Cipher(object):
    """This is the Cipher Class"""
    def __init__(self, inputString):
        self.inputString = inputString
        self.encodedString = ''
        self.decodedString = ''


    def __repr__(self):
        s = 'Original String: %s\nEncoded String: %s\nDecoded String: %s' \
                % (self.inputString, self.encodedString, self.decodedString)
        return s
            

    def encipher(self, n):
        self.shiftUp(n)


    def decipherEasy(self, n):
        self.shiftDown(n)


    def decipher(self):
        # Creates multiple lists of decoded strings, probabilities
        # and selects most probable, returns string at that index
        List = self.makeList()
        ProbList = self.listProb(List)
        MostProb = self.mostProb(ProbList)
        for i, e in enumerate(ProbList):
            if MostProb == e:
                self.decodedString = List[i]
        


    def shiftUp(self, n):
        # Checks if character is a capital or lower case letter
        # and if so, adds n to the order of the character, loops back
        n = n % 26
        N1 = range(97,123)
        N2 = range(65,91)
        for letter in self.inputString:
            if ord(letter) in N1:
                if ord(letter) + n > 122:
                    self.encodedString += chr(ord(letter) + n - 26)
                else:
                    self.encodedString += chr(ord(letter) + n)

            elif ord(letter) in N2:
                if ord(letter) + n > 90:
                    self.encodedString += chr(ord(letter) + n - 26)
                else:
                    self.encodedString += chr(ord(letter) + n)

            else:
                self.encodedString += letter


    def shiftDown(self, n):
        # Checks if character is a capital or lower case letter
        # and if so, subtracts n from the order of the character, loops back
        N1 = range(97,123)
        N2 = range(65,91)
        for letter in self.encodedString:
            if ord(letter) in N1:
                if ord(letter) - n < 97:
                    self.decodedString += chr(ord(letter) - n + 26)
                else:
                    self.decodedString += chr(ord(letter) - n)

            elif ord(letter) in N2:
                if ord(letter) - n < 65:
                    self.decodedString += chr(ord(letter) - n + 26)
                else:
                    self.decodedString += chr(ord(letter) - n)

            else:
                self.decodedString += letter


    def shiftDecode(self, n):
        # Creates string called decoded, and essentially encodes it for every
        # possibility of n, (1-26)
        Decoded = ''
        N1 = range(97,123)
        N2 = range(65,91)
        for letter in self.encodedString:
            if ord(letter) in N1:
                if ord(letter) + n > 122:
                    Decoded += chr(ord(letter) + n - 26)
                else:
                    Decoded += chr(ord(letter) + n)

            elif ord(letter) in N2:
                if ord(letter) + n > 90:
                    Decoded += chr(ord(letter) + n - 26)
                else:
                    Decoded += chr(ord(letter) + n)

            else:
                Decoded += letter

        return Decoded


    def makeList(self):
        # Creates list of decoded strings using shiftDecode
        # in range of 0 to 25
        return [self.shiftDecode(n) for n in range(26)]


    def listProb(self, L):
        # Creates a list of probabilities for each decoded string
        return [sum(letProb(n) for n in i) for i in L]


    def mostProb(self, L):
        # Sorts the list of probabilities and returns highest prob
        highest = 0
        for i in L:
            if i > highest:
                highest = i
        return highest


def main():
    W = 'I hope the bees find their way home today because its raining'
    L = Cipher(W)
    L.encipher(5)
    L.decipherEasy(1)
    L.decipher()
    print(L)

if __name__ == '__main__':
    main()