import random
from tkinter import *
import time

class Connect4:
    def __init__(self, width, height, window=None):
        self.width = width
        self.height = height
        self.playturn = 'x'
        self.data = []
        self.Playing = True
        self.resetVar = False
        
        for row in range(self.height):
            boardRow = []
            for col in range(self.width):
                boardRow += [' ']
            self.data += [boardRow]
        
    def __repr__(self):
        s = ''
        for row in range(self.height):
            s += '|'
            for col in range(self.width):
                s += self.data[row][col] + '|'
            s += '\n'
        for i in range(self.width * 2 + 1):
            s +=  '-'
        s += '\n'
        for i in range(self.width):
            s += ' ' + str(i % 10)
        s += '\n'
        return s
        

    def clear(self):
        for row in range(self.height):
            for col in range(self.width):
                self.data[row][col] = ' '

    def isFull(self):
        for col in range(self.width):
            if self.allowsMove(col):
                return False
        return True

    def winsFor(self, ox):
        for row in range(self.height):
            for col in range(self.width - 3):
                if self.data[row][col] == ox and \
                self.data[row][col+1] == ox and \
                self.data[row][col+2] == ox and \
                self.data[row][col+3] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width):
                if self.data[row][col] == ox and \
                self.data[row + 1][col] == ox and \
                self.data[row + 2][col] == ox and \
                self.data[row + 3][col] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row][col] == ox and \
                self.data[row + 1][col + 1] == ox and \
                self.data[row + 2][col + 2] == ox and \
                self.data[row + 3][col + 3] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row][col + 3] == ox and \
                self.data[row + 1][col + 2] == ox and \
                self.data[row + 2][col + 1] == ox and \
                self.data[row + 3][col] == ox:
                    return True

        for row in range(self.height - 3):
            for col in range(self.width - 3):
                if self.data[row + 3][col] == ox and \
                self.data[row + 2][col + 1] == ox and \
                self.data[row + 1][col + 2] == ox and \
                self.data[row][col + 3] == ox:
                    return True

        return False


    def addMove(self, col, ox):
        for i in range(self.height + 1):
            if self.allowsMove(col):
                i = -(i + 1)
                if self.data[i][col] == ' ':
                    self.data[i][col] = ox
                    break

    def delMove(self, col):
        for i in range(self.height):
            if self.data[i][col] != ' ':
                self.data[i][col] = ' '
                break

    def allowsMove(self, col):
        if col < self.width and col >= 0:
            for i in range(self.height):
                if self.data[i][col] == ' ':
                    return True
        return False

    def flipTurn(self, ox):
        if ox == 'o':
            return 'x'
        elif ox == 'x':
            return  'o'

    def resetGame(self):
        self.clear()
        self.Playing = True
        self.resetVar = True


    def playGameWith(self, aiPlayer):
        self.clear()
        while True:
            print(self)
            print('Player turn: ' + self.playturn)
            move = int(input('Column: '))
            if self.allowsMove(move):
                self.addMove(move, self.playturn)
            else:
                print('Invalid move!')

            if self.winsFor(self.playturn):
                print(self)
                print(self.playturn + ' won!')
                break
            elif self.isFull():
                print('Game over!')
                break

            if self.allowsMove(move):
                self.addMove(aiPlayer.nextMove(self), self.flipTurn(self.playturn))

                if self.winsFor(self.flipTurn(self.playturn)):
                    print(self)
                    print(self.flipTurn(self.playturn) + ' won!')
                    break
                elif self.isFull():
                    print('Game over!')
                    break

    def playGameFull(self, aiPlayer, canvas):
        while True:
            while self.Playing:
                canvas.updateWindow()
                canvas.drawCheckers(self)
                if aiPlayer.ply != canvas.difficulty:
                    aiPlayer.ply = int(canvas.difficulty)
                if self.resetVar:
                    self.resetVar = False
                    canvas.drawText("Connect4")
                if canvas.chosen >= 0 and canvas.chosen < self.width:
                    canvas.drawText("AI turn")
                    self.addMove(canvas.chosen, self.playturn)
                    canvas.drawCheckers(self)
                    canvas.updateWindow()

                    if self.winsFor(self.playturn):
                        canvas.drawText("Black Won!")
                        canvas.drawCheckers(self)
                        self.Playing = False
                        break
                    elif self.isFull():
                        canvas.drawText("Cat's Game!")
                        canvas.drawCheckers(self)
                        self.Playing = False
                        break

                    time.sleep(0.1)
                    canvas.drawText("Your turn")
                    self.addMove(aiPlayer.nextMove(self), self.flipTurn(self.playturn))
                    canvas.drawCheckers(self)

                    if self.winsFor(self.flipTurn(self.playturn)):
                        canvas.drawText("Red Won!")
                        canvas.drawCheckers(self)
                        self.Playing = False
                        break
                    elif self.isFull():
                        canvas.drawText("Cat's Game!")
                        canvas.drawCheckers(self)
                        self.Playing = False
                        break

                    canvas.chosen = -1
            canvas.chosen = -1
            canvas.updateWindow()



class Player:
    def __init__(self, ox, tbt, ply):
        self.checker = ox
        self.tieBreakType = tbt
        self.ply = ply


    def scoresFor(self, board, ox, ply):
        L1 = [0 for i in range(board.width)]
        for col in range(board.width):
            if board.allowsMove(col):
                board.addMove(col, ox)
                if board.winsFor(board.flipTurn(ox)):
                    L1[col] = 0
                elif board.winsFor(ox):
                    L1[col] = 100
                else:
                    L1[col] = 50
                    
                if ply > 0:
                    L2 = self.scoresFor(board, board.flipTurn(ox), ply - 1)
                    L1[col] = 100 - max(L2)
                board.delMove(col)
            else:
                L1[col] = -1

        print(L1)
        return L1
                

    def tieBreak(self, L):
        if self.tieBreakType == 'Left':
            m = L.index(max(L))
        elif self.tieBreakType == 'Right':
            x = 0
            for j,i in enumerate(L):
                if i >= x:
                    x = i
                    m = j
        elif self.tieBreakType == 'Random':
            x = 0
            y = random.randint(0, len(L))
            for j,i in enumerate(L):
                if i >= x and j < y:
                    x = i 
                    m = j
        return m

    def nextMove(self, board):
        L = self.scoresFor(board, self.checker, self.ply)
        L = self.tieBreak(L)
        return L


class ConnectWindow:
    def __init__(self, board, aiPlayer):
        self.win = Tk()
        self.win.title("Connect Four")
        self.winWidth = 700
        self.winHeight = board.height*int(700/board.width)
        self.difficulty = aiPlayer.ply

        self.canvas1 = Canvas(self.win, width=self.winWidth, height=150, bg="darkgrey")
        self.canvas1.bind("<Button-1>", self.checkMove)
        self.canvas1.pack(side=TOP)
        self.canvas2 = Canvas(self.win, width=self.winWidth, height=self.winHeight, bg="blue")
        self.canvas2.bind("<Button-1>", self.checkMove)
        self.canvas2.pack()
        self.canvas3 = Canvas(self.win, width=self.winWidth, height=100, bg="darkgrey")
        self.canvas3.bind("<Button-1>", self.checkMove)
        self.canvas3.pack(side=BOTTOM)

        self.setButton = Button(self.canvas1, text="Reset", fg="grey", command=board.resetGame)
        self.exitButton = Button(self.canvas1, text="Quit", fg="grey", command=self.quitGame)
        self.plyScale = Scale(self.canvas1, orient=HORIZONTAL, to=7, length=200, label="Difficulty -->", command=self.callbackProcedure)
        self.plyScale.pack(side=LEFT)
        self.setButton.pack(anchor='e')
        self.exitButton.pack(anchor='e')
        self.playText = self.canvas3.create_text(self.winWidth/2, 50, text="Connect4", anchor=CENTER, font="Courier 24")
        self.chosen = -1

    def drawCheckers(self, board):
        self.checkWidth = int(700/board.width) - 11
        x = 10
        y = 10
        for row in range(board.height):
            for col in range(board.width):
                if board.data[row][col] == ' ':
                    color = "darkgrey"
                elif board.data[row][col] == 'x':
                    color = "black"
                elif board.data[row][col] == 'o':
                    color = "red"
                self.canvas2.create_oval(x, y, x+self.checkWidth, y+self.checkWidth, outline="black", width=2, fill=color)
                x += self.checkWidth + 10
            y += self.checkWidth + 10
            x = 10

    def drawText(self, turn):
        self.canvas3.itemconfig(self.playText, text=turn)

    def updateWindow(self):
        self.win.update()


    def checkMove(self, event):
        x = int(event.x/(self.checkWidth+10))
        self.chosen = x

    def callbackProcedure(self, num):
        self.difficulty = num

    def quitGame(self):
        self.win.destroy()

def main():
    D = Connect4(7, 7)
    P = Player('o', 'Right', 0)
    C = ConnectWindow(D, P)
    D.playGameFull(P, C)

if __name__ == '__main__':
    main()